"BeamlineSuperMouse module."

from xml.sax import parseString

from cdb._base import _get_string_from_date
from cdb._beamline import Beamline

__all__ = ["BeamlineSuperMouse"]

class BeamlineSuperMouse(Beamline):
    
    """
The BeamlineSuperMouse class is used to set and retrieve  beam line settings.

Beam line data is stored on a per run basis. All available data can be retrieved
using get_all_beamlines. A number of methods are available to retrieve subsets
of the data, get_beamline_for_run, get_beamlines_for_dates and
get_beamlines_for_pulses.

    """
    
    def __init__(self):
        """
Construct a BeamlineSuperMouse.

@exception CdbPermanentError: Unable to contact CDB server or invalid URL

        """

        super(BeamlineSuperMouse, self).__init__("/cdb/beamlineSuperMouse?wsdl")

    def __str__(self):
        return "BeamlineSuperMouse \
        \n\tset_url(string url) \
        \n\tget_status() \
        \n\tget_all_beamlines() \
        \n\tget_all_beamlines_xml() \
        \n\tget_beamline_for_run(string run_number) \
        \n\tget_beamline_for_run_xml(int run_number) \
        \n\tget_beamlines_for_dates(datetime start_time, datetime stop_time) \
        \n\tget_beamlines_for_dates_xml(datetime start_time, datetime stop_time) \
        \n\tget_beamlines_for_pulses(int start_pulse, int end_pulse) \
        \n\tget_beamlines_for_pulses_xml(int start_pulse, int end_pulse) \
        \n\tadd_run(int run_number, datetime start_time, string notes, \
        \n\t\tstring optics, int proton_absorber_thickness, int pulse_start, \
        \n\t\tfloat step, string run_type, string daq_trigger, \
        \n\t\tfloat daq_gate_width, string daq_version, int isis_target_frequency, \
        \n\t\tfloat isis_rep_rate, float isis_nominal_beam_current, \
        \n\t\tfloat isis_nominal_beam_loss, float isis_beam_position_x, \
        \n\t\tfloat isis_beam_position_y, float target_depth, float target_delay, \
        \n\t\tfloat target_drive_voltage) \
        \n\tupdate_run(int run_number, datetime end_time, int pulse_end, \
        \n\t\tboolean status)" 

    def add_run(self, run_number, start_time, notes, optics,
    proton_absorber_thickness, pulse_start, step, run_type, daq_trigger,
    daq_gate_width, daq_version, isis_target_frequency, isis_rep_rate,
    isis_nominal_beam_current, isis_nominal_beam_loss, isis_beam_position_x,
    isis_beam_position_y, target_depth, target_delay, target_drive_voltage):
        """
Add the initial parameters associated with a run.

@param run_number: an int representing the run number
@param start_time: a datetime that should represent the time the run started
@param notes: a string
@param optics: a string representing the beamline optics
@param proton_absorber_thickness: an int representing the thickness of the proton absorber in mm
@param pulse_start: an int representing the total number of pulses at start of run
@param step: a float representing the MICE phase
@param run_type: a sting of 32 bits, each bit is a flag for a run type
@param daq_trigger: a string
@param daq_gate_width: a float representing the gate width in ms
@param daq_version: a string
@param isis_target_frequency: an int
@param isis_rep_rate: a float representing the isis rep rate in Hz
@param isis_nominal_beam_current: a float representing the isis nominal beam current in uA
@param isis_nominal_beam_loss: a float representing the isis nominal beam loss in mV
@param isis_beam_position_x: a float representing the isis x co-ordinate of the beam
@param isis_beam_position_y: a float representing the isis y co-ordinate of the beam
@param target_depth: a float representing the target depth in mm
@param target_delay: a float representing the target delay
@param target_drive_voltage: a float representing the target_drive_voltage in V

@return a string containing a status message
        """
        
        run_xml = ("<run runNumber='" + str(run_number)
        + "' startTime='" + _get_string_from_date(start_time)
        + "' notes='" + str(notes)
        + "' optics='" + str(optics)
        + "' protonAbsorberThickness='" + str(proton_absorber_thickness)
        + "' pulseStart='" + str(pulse_start)
        + "' step='" + str(step)
        + "' runType='" + str(run_type)
        + "' daqTrigger='" + str(daq_trigger)
        + "' daqGateWidth='" + str(daq_gate_width)
        + "' daqVersion='" + str(daq_version)
        + "' isisTargetFrequency='" + str(isis_target_frequency)
        + "' isisRepRate='" + str(isis_rep_rate)
        + "' isisNominalBeamCurrent='" + str(isis_nominal_beam_current)
        + "' isisNominalBeamLoss='" + str(isis_nominal_beam_loss)
        + "' isisBeamPositionX='" + str(isis_beam_position_x)
        + "' isisBeamPositionY='" + str(isis_beam_position_y)
        + "' targetDepth='" + str(target_depth)
        + "' targetDelay='" + str(target_delay)
        + "' targetDriveVoltage='" + str(target_drive_voltage)
        + "' />")
        xml = str(self._client.addRun(str(run_xml)))
        parseString(xml, self._status_handler)
        return self._status_handler.get_message()
            
    def update_run(self, run_number, end_time, pulse_end, status):
        """
Add the parameters associated with the end of a run.

@param run_number: an int representing the run number
@param end_time: a datetime that should represent the time the run ended
@param pulse_end: an int representing the total number of pulses at start of run
@param status: a boolean, true indicates data are analysable

@return a string containing a status message
        """
        run_xml = ("<endRun runNumber='" + str(run_number)
        + "' endTime='" + _get_string_from_date(end_time)
        + "' pulseEnd='" + str(pulse_end)
        + "' status='" + str(int(status))   
        + "' />")
        xml = str(self._client.updateRun(run_xml))
        parseString(xml, self._status_handler)
        return self._status_handler.get_message()

