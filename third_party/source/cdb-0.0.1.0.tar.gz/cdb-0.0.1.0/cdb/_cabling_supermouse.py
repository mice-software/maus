"CablingSuperMouse module."

from xml.sax import parseString

from cdb._cabling import Cabling

__all__ = ["CablingSuperMouse"]

class CablingSuperMouse(Cabling):
    
    """
The CablingSuperMouse class is used to set and retrieve cabling data.

For the control system a channel is described by its location with reference to
a crate and module. For the detectors and trackers a channel is described by its
location with reference to computer id and geo number. Each channel has data
associated with it. Old versions of the data are stored for diagnostic purposes.
Data can be retrieved for a given time using get_cabling_for_date and for a
given run using get_cabling_for_run.

    """
    
    def __init__(self):
        """
Construct a CablingSuperMouse.

@exception CdbPermanentError: Unable to contact CDB server or invalid URL

        """
        super(CablingSuperMouse, self).__init__("/cdb/cablingSuperMouse?wsdl")
       
    def __str__(self):
        return "CablingSuperMouse \
        \n\tset_url(string url) \
        \n\tget_status() \
        \n\tget_cabling_for_date(string device, datetime timestamp) \
        \n\tget_cabling_for_run(string device, int run_number) \
        \n\tget_current_cabling(string device) \
        \n\tlist_devices() \
        \n\tadd_control(int crate, int module, int channel, string name) \
        \n\tupdate_control(int crate, int module, int channel, string name) \
        \n\tadd_tracker(string name, int vlsb_computer_id, int vlsb_geo_number, \
        \n\t\tint vlsb_channel, int tracker_no, int station, int plane, int channel)\
        \n\tupdate_tracker(string name, int vlsb_computer_id, int vlsb_geo_number, \
        \n\t\tint vlsb_channel, int tracker_no, int station, int plane, \
        \n\t\tint channel)"

    def add_control(self, crate, module, channel, name):
        """
Add the cabling data. A timestamp is associated with the data. N.B. There must
NOT already be an entry for the crate, module, channel otherwise an error will
be reported.
    
@param crate: the number of the crate
@param module: the number of the module
@param channel: the number of the channel
@param name: a string containing the name of the device that is connected to the channel

@return a string containing a status message
        """
        xml = str(self._client.addControl(crate, module, channel, name))
        parseString(xml, self._status_handler)
        return self._status_handler.get_message()
            
    def update_control(self, crate, module, channel, name):
        """
Update the cabling data. A timestamp is associated with the data. N.B. There
must already be an entry for the crate, module, channel otherwise an error will
be reported.
    
@param crate: the number of the crate
@param module: the number of the module
@param channel: the number of the channel
@param name: a string containing the name of the device that is connected to the channel

@return a string containing a status message
        """
        xml = str(self._client.updateControl(crate, module, channel, name))
        parseString(xml, self._status_handler)
        return self._status_handler.get_message()

    def add_tracker(self, name, vlsb_computer_id, vlsb_geo_number, vlsb_channel,
    tracker_no, station, plane, channel):
        """
Add the cabling data. A timestamp is associated with the data.N.B. There must
NOT already be an entry for the vlsb_computer_id, vlsb_geo_number, vlsb_channel
otherwise an error will be reported.
    
@param name: a string containing the name of the tracker
@param vlsb_computer_id: the number of the vlsb computer id
@param vlsb_geo_number: the number of the vlsb geo number
@param vlsb_channel: the number of the vlsb channel
@param tracker_no: the number of the tracker
@param station: the number of the station
@param plane: the number of the plane
@param channel: the number of the channel 

@return a string containing a status message
        """
        xml = str(self._client.addTracker(name, vlsb_computer_id,
        vlsb_geo_number, vlsb_channel, tracker_no, station, plane, channel))
        parseString(xml, self._status_handler)
        return self._status_handler.get_message()
            
    def update_tracker(self, name, vlsb_computer_id, vlsb_geo_number,
    vlsb_channel, tracker_no, station, plane, channel):
        """
Update the cabling data. A timestamp is associated with the data.N.B. There must
NOT already be an entry for the vlsb_computer_id, vlsb_geo_number, vlsb_channel
otherwise an error will be reported.
    
@param name: a string containing the name of the tracker
@param vlsb_computer_id: the number of the vlsb computer id
@param vlsb_geo_number: the number of the vlsb geo number
@param vlsb_channel: the number of the vlsb channel
@param tracker_no: the number of the tracker
@param station: the number of the station
@param plane: the number of the plane
@param channel: the number of the channel 

@return a string containing a status message
        """
        xml = str(self._client.updateTracker(name, vlsb_computer_id,
        vlsb_geo_number, vlsb_channel, tracker_no, station, plane, channel))
        parseString(xml, self._status_handler)
        return self._status_handler.get_message()

