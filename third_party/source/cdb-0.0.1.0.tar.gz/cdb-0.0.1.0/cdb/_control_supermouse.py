"ControlSuperMouse module."

from xml.sax import parseString

from cdb._control import Control

__all__ = ["ControlSuperMouse"]

class ControlSuperMouse(Control):
    
    """
The ControlSuperMouse class is used to set and retrieve control parameter values.

Old control parameter values are stored for diagnostic purposes. A set of
control parameter values can be retrieved for a given time using
get_previous_settings

    """
    
    def __init__(self):
        """
Construct a ControlSuperMouse.

@exception CdbPermanentError: Unable to contact CDB server or invalid URL

        """
        super(ControlSuperMouse, self).__init__("/cdb/controlSuperMouse?wsdl")
       
    def __str__(self):
        return "ControlSuperMouse \
        \n\tset_url(string url) \
        \n\tget_status() \
        \n\tget_controls() \
        \n\tget_controls_for_crate(int crate) \
        \n\tget_previous_settings(string timestamp) \
        \n\tset_parameter(int crate, int module, int channel, string parameter_name, \
        \n\t\t string parameter_value) \
        \n\tupdate parameter(int crate, int module, int channel, string parameter_name, \
        \n\t\tstring parameter_value)"


    def set_parameter(self, crate, module, channel, parameter_name,
                      parameter_value):
        """
Set the parameter value of an individual parameter for the given channel. A
timestamp is associated with the parameter. N.B. There must NOT already be a
value set for the parameter otherwise an error will be reported.
    
@param crate: the number of the crate
@param module: the number of the module
@param channel: the number of the channel
@param parameter_name: a string containing the name of the parameter
@param parameter_value: a string containing the value to set 

@return a string containing a status message
        """
        xml = str(self._client.setParameter(crate, module, channel,
                                            parameter_name, parameter_value))
        parseString(xml, self._status_handler)
        return self._status_handler.get_message()
            
    def update_parameter(self, crate, module, channel, parameter_name,
                         parameter_value):
        """
Update the parameter value of an individual parameter for the given channel. The
timestamp associated with the parameter is updated to the current time.N.B.
There must already be a value set for the parameter otherwise an error will be
reported.
    
@param crate: the number of the crate
@param module: the number of the module
@param channel: the number of the channel
@param parameter_name: a string containing the name of the parameter
@param parameter_value: a string containing the value to set 

@return a string containing a status message
        """
        xml = str(self._client.updateParameter(crate, module, channel,
                                               parameter_name, parameter_value))
        parseString(xml, self._status_handler)
        return self._status_handler.get_message()

