#!/bin/bash

#######################################
# Functions                           #
#######################################

function DrawLine()
{
	# Set up variables
	local TERMINAL_WIDTH=$(tput cols)
	local DIVIDER_CHAR=
	local DIVIDER_LINE=
	
	# Check whether a divider character has been specified
	if test -z "$1"
	then
		DIVIDER_CHAR="-"
	else
		DIVIDER_CHAR="$1"
	fi
	
	# Generate divider line
	for (( INDEX = 0 ; INDEX < $TERMINAL_WIDTH ; INDEX++ ))
	do
		DIVIDER_LINE="$DIVIDER_LINE""$1"
	done
	
	# Output divider line
	echo $DIVIDER_LINE
	
	return 0
}

#######################################

function AddFiles()
{
	DrawLine "="
	echo "Adding new files..."
	DrawLine "="
	bzr add .
	echo ""
	
	return 0
}

#######################################

function DisplayStatus()
{
	DrawLine "-"
	echo "Branch information:"
	DrawLine "-"
	bzr info
	
	DrawLine "-"
	echo "Changes since last commit:"
	DrawLine "-"
	bzr status
	
	DrawLine "-"
	echo "Ignored Files:"
	DrawLine "-"
	bzr ignored
	
	return 0
}

#######################################

function Commit()
{
	# Set up variables
	local PREFERRED_EDITOR="nano"
	local COMMIT_OPTS=
	local REPLY=
	
	# Check whether we are performing a normal commit
	# or a local one
	if [ "$1" == "local" ]
	then
		COMMIT_OPTS="--local"
	fi
	
	# Ask whether user is sure that they want to commit
	DrawLine "+"
	read -p "Really perform commit? (y/n)" REPLY
	DrawLine "+"
	echo ""
	
	if [ "$REPLY" == "y" ]
	then
		DrawLine "="
		export EDITOR="$PREFERRED_EDITOR"
		bzr commit "$COMMIT_OPTS"
	else
		DrawLine "~"
		echo "Commit aborted"
		DrawLine "~"
	fi
	
	return 0
}

#######################################
# Perform typical commit sequence     #
#######################################

AddFiles

unset LESS
DisplayStatus | less

Commit $1
