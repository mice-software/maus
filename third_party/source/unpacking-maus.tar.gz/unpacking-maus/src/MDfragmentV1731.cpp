/***************************************************************************
 *                                                                         *
 * Originally created by J.S. Graulich May 2011                            *
 *                                                                         *
 ***************************************************************************/

#include "MDfragmentV1731.h"

MDfragmentV1731::MDfragmentV1731(void *d):MDfragment(d){ 
  // A fragment should be created only once inside the map
  //   cout << " Creating a MDfragmentV1731 ..." << endl; 
 _partEventPtr = new MDpartEventV1731(0);
  Init();
}

void MDfragmentV1731::SetDataPtr( void *d, uint32_t aSize ) {
  MDfragment::SetDataPtr(d, aSize);
}

void MDfragmentV1731::Init(){
  uint32_t * ptr = Get32bWordPtr(0);
  MDdataWordV1731 dw(ptr);
  //  cout << " Executing MDfragmentV1731::Init() ..." << endl; 
  UnValidate();
  _madeOfParticles = true;

  if ( dw.IsValid() ) { 
   // TODO : Basic checks on the data consistency
    Validate();
  }
  //  cout << "  ... Done with MDfragmentV1731" << endl; 
}

////////////////////////////////////////////////////////////////////////


