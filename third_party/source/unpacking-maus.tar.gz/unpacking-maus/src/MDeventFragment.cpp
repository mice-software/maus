/***************************************************************************
 *                                                                         *
 * $Log: MDeventFragment.cpp,v $
 * Revision 1.1  2008/04/14 11:40:45  daq
 * Initial revision
 *
 * Revision 1.7  2008/04/10 11:13:36  daq
 * Improve recovery procedure.
 * Improve dump output format
 *
 * Revision 1.6  2008/04/08 14:04:01  daq
 * Introduce vector of particle events.
 * Introduce new member function InitPartEventVector().
 *
 * Revision 1.5  2008/01/25 10:10:47  daq
 * Introduce the new MDequipMap scheme
 *
 *
 * Originally created by J.S. Graulich june 2007                           *
 *                                                                         *
 ***************************************************************************/
#include "MDeventFragment.h"

MDeventFragment::MDeventFragment(void *d):MDdataContainer(d){
  Init();
};

void MDeventFragment::Init() {
  nPartEvents = 0;
  _valid = false;
  if (_data) {
    _size = *EquipmentSizePtr();
    _valid = true;
  }
} 

void MDeventFragment::SetDataPtr( void *d ) { 
  MDdataContainer::SetDataPtr(d);
  Init();
}

unsigned long32 MDeventFragment::InitPartEventVector(){
  static int recoverTrick(0);
  MDequipMap eMap;
  equipMap::iterator iter;
  MDdataContainer* dc;
  unsigned long32 npe(0);
  try {
    partEvent.clear();
    if(  EquipmentDataSize() ){
      unsigned char* ptr = EquipmentDataPtr();
      // look for the equipment type in the equipment map
      iter = eMap.find( *EquipmentTypePtr() );
      if( ( iter->first == *EquipmentTypePtr() ) ){ 
	// The equipment has been found in the map.
	// Dynamic allocation
	dc = eMap.GetDataContainerPtr(*EquipmentTypePtr());
	// dc is now a pointer to a MDpartEventXXX 
	// Loop over the particle events 
	while (ptr < _data + *EquipmentSizePtr() ) { // while we have not reached the end of the Fragment
	  dc->SetDataPtr( ptr );
	  if ( dc->IsValid() ) {
	    if (recoverTrick) {
	      recoverTrick = 0;
	      cout << " ... Recovery trick successful. Continuing... " << endl;
	    }
	    npe++;
	    partEvent.push_back(ptr);
	    ptr += dc->GetSize();
	    if (ptr > _data + *EquipmentSizePtr() ) {
	      cerr << " *** ERROR in MDeventFragment::NpartEvent: *** " <<  endl;
	      cout << " *** ERROR in MDeventFragment::NpartEvent: *** " <<  endl;
	      cout << " for " << eMap.GetName(*EquipmentTypePtr()) << endl ;
	      cout << " Internal data size is larger than size in file " << endl;
	      cout << " Trying to recover... " << endl;
	      ptr = _data + *EquipmentSizePtr(); // skip the remaining data
	    }
	  } else {
	    cout << " INVALID particle event found for " << eMap.GetName(*EquipmentTypePtr()) << endl;
	    cout << " Trying to recover... " << endl;
	    if ( (strcmp(eMap.GetName(*EquipmentTypePtr()).c_str(), "V1724")==0)
		 && (recoverTrick < 1) ) {
	      cout << " Applying trick " << endl; 
	      recoverTrick++;
	      ptr -= 16; // Known bug in early version of DAQ readout for V1724
	    } else {
	      ptr = _data + *EquipmentSizePtr();
	    }
	  }
	}
      } else { // There is some data but the equipment is not in the map
	npe = 1;
	partEvent.push_back(ptr);
      }
    }

    nPartEvents = npe;
    /*
      if (nPartEvents) {
      cout << nPartEvents << " particle event(s) found " ;
      if ( iter->first == *EquipmentTypePtr() ) {
      cout << " for " << eMap.GetName(*EquipmentTypePtr()) ; }
      cout << endl << flush; 
      } else {
      cout << " No particle Event found " << endl << flush;
      }
    */
  }
  catch ( MDexception & lExc) {
    std::cerr << "Unpacking exception" << std::endl;
    std::cerr << lExc.GetDescription() << std::endl;
    throw;
  }
  catch(std::exception & lExc) {
    std::cerr << "Standard exception" << std::endl;
    std::cerr << lExc.what() << std::endl;
    throw;
  }
  catch(...) {
    std::cerr << "Unknown exception occurred..." << std::endl;
    throw;
  }
  return nPartEvents;
}

void MDeventFragment::Dump(int atTheTime){
  MDequipMap eMap;
  MDdataContainer* dc;
  equipMap::iterator iter = eMap.find( *EquipmentTypePtr() );
  
  int i;
  cout << "- - - - - - - - - - - - - MDeventFragment Dump - - - - - - - - - - - - - - - - " << dec << endl;
  cout << "Size:" << *EquipmentSizePtr() 
       << " (header:" << sizeof(equipmentHeaderStruct) << ")"
       << " Type:" << *EquipmentTypePtr()
       << " EquipId:" << *EquipmentIdPtr()
       << " BasicSize:" << *BasicElementSizePtr() <<  endl;
  cout << "Attributes: (" ;
  for ( i = 0; i != ALL_ATTRIBUTE_WORDS; i++ ) {
    cout << noshowbase << setfill('0') << setw(8) << hex << EquipmentTypeAttributePtr()[i];
    if ( i != ALL_ATTRIBUTE_WORDS-1 ) cout << ".";
  }
  cout << ")" << endl ; 

  InitPartEventVector();
  cout << "Equipment Name: " ;
  if( ( iter->first == *EquipmentTypePtr() ) ) { // The equipment has been found in the map
    cout << eMap.GetName(*EquipmentTypePtr()) << endl ;
  } else {
    cout << " N/A " << endl ;
  }
  cout << "Number of Particle events: " << dec << GetNPartEvents() << endl ;

  for (unsigned int ipe=0; ipe<nPartEvents; ipe++) {
    if( ( iter->first == *EquipmentTypePtr() ) ){ // The equipment has been found in the map
      dc = eMap.GetDataContainerPtr(*EquipmentTypePtr());
      dc->SetDataPtr( partEvent[ipe] );
      dc->Dump();
    } else { // unknown equipment, dump words without decoding.
      dc = new MDdataContainer(partEvent[ipe]);
      dc->SetSize(EquipmentDataSize());
      dc->Dump(4);
      delete dc;
    }
  } 

  /*
  if(  EquipmentDataSize() ){
    recoverTrick =0;
    unsigned char* ptr = EquipmentDataPtr();
    equipMap::iterator iter = eMap.find( *EquipmentTypePtr() );
    if( ( iter->first == *EquipmentTypePtr() ) ){ // The equipment has been found in the map
      cout << " Decoding equipment " << eMap.GetName(*EquipmentTypePtr()) << endl ;
      dc = eMap.GetDataContainerPtr(*EquipmentTypePtr());
      while (ptr < _data + *EquipmentSizePtr() ) {
	dc->SetDataPtr( ptr );
	if ( dc->IsValid() ) {
	  if (recoverTrick) {
	    recoverTrick = 0;
	    cout << " ... Recovery trick successful. Continuing... " << endl;
	  }
	  dc->Dump();
	  ptr += dc->GetSize();
	  if (ptr > _data + *EquipmentSizePtr() ) {
	    cout << " *** ERROR in MDeventFragment::Dump : *** " <<  endl;
	    cout << " While decoding equipment " << eMap.GetName(*EquipmentTypePtr()) << endl ;
	    cout << " Internal data size is larger than size in file " << endl;
	    cout << " Trying to recover... " << endl;
	    ptr = _data + *EquipmentSizePtr();
	  }
	} else {
	  cout << " Trying to recover format error in equipment " 
	       << eMap.GetName( *EquipmentTypePtr() ) << " ... " << endl ;
	  if (recoverTrick < 1) {
	    cout << " Applying trick " << endl; 
	    recoverTrick++;
	    ptr -= 16; // Known bug in early version of DAQ
	  } else {
	    ptr = _data + *EquipmentSizePtr();
	  }
	}
      }
    } else { // unknown equipment, dump words without decoding.
      dc = new MDdataContainer(ptr);
      dc->SetSize(EquipmentDataSize());
      dc->Dump(4);
      delete dc;
    }
  }
  */
};
