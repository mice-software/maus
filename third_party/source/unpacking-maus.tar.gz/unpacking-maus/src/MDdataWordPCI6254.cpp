/***************************************************************************
 *                                                                         *
 * $Log: MDdataWordPCI6254.cpp,v $
 * Revision 1.1  2009/04/21 12:35:22  daq
 * Initial revision
 *
 *                                                                         *
 * Originally created by J.S. Graulich, February 2009                      *
 *                                                                         *
 ***************************************************************************/
#include "MDdataWordPCI6254.h"
 
//default constructor 
MDdataWordPCI6254::MDdataWordPCI6254(void *d):MDdataWord(d){}


void MDdataWordPCI6254::Dump(int atTheTime){
  cout << *this;
  return;
} 

ostream &operator<<( ostream &s,MDdataWordPCI6254 &dw){
  s << showbase << hex << showbase ;
  s << " PCI6254 data : ";
  s << *(dw.Get32bWordPtr()) ;
  s << " (or  " << dec << *((float*)dw.Get32bWordPtr() )<< ")" <<  endl ;

  return s;
}
