/***************************************************************************
 *                                                                         *
 * $Log: MDpartEventV1724.cpp,v $
 * Revision 1.2  2008/04/29 07:35:02  daq
 * Add {} for switch cases for better portability.
 *
 * Revision 1.1  2008/04/14 11:40:45  daq
 * Initial revision
 *
 * Revision 1.3  2008/04/08 13:56:25  daq
 * Remove debug info.
 * Add error message for invalid particle events.
 *
 * Revision 1.2  2008/01/31 00:31:48  daq
 * Implement GetSampleData() and other functions used by it.
 * Introduce need private data: _nChannels, _length and _sequence
 *
 * Revision 1.1  2008/01/25 10:14:02  daq
 * Initial revision
 *
 *                                                                         *
 * Originally created by J.S. Graulich December 2007                       *
 *                                                                         *
 ***************************************************************************/

#include "MDpartEventV1724.h"

MDpartEventV1724::MDpartEventV1724(void *d):MDdataContainer(d){ 
  UnValidate();
  Init();
}

void MDpartEventV1724::Init(){
  UnValidate();
  unsigned int * header = Get32bWordPtr(0);
  int index;
  unsigned int length;
  if (header) {
    if ( (header[DWV1724_Header_Sync_Word] & DWV1724_Header_Sync_Mask) == DWV1724_Header_Sync ) {
      Validate();
      SetSize( GetWordCount() * V1724_WORD_SIZE ); 
      //      cout << "Size : " << dec << 4*GetWordCount() << " ( " << hex << showbase << 4*GetWordCount() << " ) " << endl; 

      // find the number of non null bit in the channel mask:
      _nChannels = 0;
      for (unsigned int ch=0; ch < V1724_NCHANNELS ; ch++) {
	_nChannels += (GetChannelMask()>>ch) & 0x00000001;
      }

      switch( GetZLE() ) {
      case 0: 
	{ // No zero length encoding. Life is easy.
	  length = (GetWordCount() - V1724_HEADER_WORDS)/_nChannels;
	  for (unsigned int ch=0; ch < V1724_NCHANNELS ; ch++) {
	    _length[ch] = ((GetChannelMask()>>ch) & 0x00000001)*length;
	    if ( _length[ch] )
	      _sequence[ch] = Get32bWordPtr(V1724_HEADER_WORDS + ch*length);
	    else _sequence[ch] = NULL;
	    // cout << " Init ch " <<  ch << " : " << _length[ch] << " ; " << _sequence[ch] << endl;
	  }
	  break;
	}
      case 1: 
	{ // Zero length encoding. That's a pain
	  index = V1724_HEADER_WORDS;
	  for (unsigned int ch=0; ch < V1724_NCHANNELS ; ch++) {
	    // Not tested !
	    // what if some channels are disabled ?
	    _sequence[ch] = Get32bWordPtr(index);
	    _length[ch] += _sequence[ch][0];
	    index +=_length[ch];
	  }
	  break;
	}
      default: 
	{ // Invalid data structure
	  cerr << "****  ERROR in MDpartEventV1724::Init: "
	       << "Unexpected ZLE ****" << endl ;
	  return;
	  break;
	}
      }
    } else {
      cerr << "****  ERROR in MDpartEventV1724::Init: "
	   << "INVALID particle Event ****" << endl ;
      cout << "****  ERROR in MDpartEventV1724::Init: "
	   << "INVALID particle Event ****" << endl ;
      cout << "Data Word : " << hex << showbase << Get32bWordPtr(0) << endl;
    }
  }
}

void MDpartEventV1724::SetDataPtr( void *d ) {
  MDdataContainer::SetDataPtr(d);
  Init();
}

unsigned int MDpartEventV1724::GetWordCount(){
  if (IsValid()) {
  unsigned int * header = Get32bWordPtr(0);
  return ( header[DWV1724_Header_WordCount_Word] & DWV1724_Header_WordCount_Mask ) >> DWV1724_Header_WordCount_Shift;
  } else {
    return 0;
  }
}

unsigned int MDpartEventV1724::GetGeo(){
  if (IsValid()) {
  unsigned int * header = Get32bWordPtr(0);
  return ( header[DWV1724_Header_Geo_Word] & DWV1724_Header_Geo_Mask ) >> DWV1724_Header_Geo_Shift;
  } else {
    return 0;
  }
}

int MDpartEventV1724::GetZLE(){
  if (IsValid()) {
  unsigned int * header = Get32bWordPtr(0);
  return ( header[DWV1724_Header_ZLE_Word] & DWV1724_Header_ZLE_Mask ) >> DWV1724_Header_ZLE_Shift;
  } else {
    return -1;
  }
}

unsigned int MDpartEventV1724::GetPattern(){
  if (IsValid()) {
  unsigned int * header = Get32bWordPtr(0);
  return ( header[DWV1724_Header_Pattern_Word] & DWV1724_Header_Pattern_Mask ) >> DWV1724_Header_Pattern_Shift;
  } else {
    return 0;
  }
}

unsigned int MDpartEventV1724::GetChannelMask(){
  if (IsValid()) {
  unsigned int * header = Get32bWordPtr(0);
  return ( header[DWV1724_Header_ChannelMask_Word] & DWV1724_Header_ChannelMask_Mask ) >> DWV1724_Header_ChannelMask_Shift;
  } else {
    return 0;
  }
}

unsigned int MDpartEventV1724::GetEventCounter(){
  if (IsValid()) {
  unsigned int * header = Get32bWordPtr(0);
  return ( header[DWV1724_Header_EventCounter_Word] & DWV1724_Header_EventCounter_Mask ) >> DWV1724_Header_EventCounter_Shift;
  } else {
    return 0;
  }
}

unsigned int MDpartEventV1724::GetTriggerTimeTag(){
  if (IsValid()) {
  unsigned int * header = Get32bWordPtr(0);
  return ( header[DWV1724_Header_TriggerTimeTag_Word] & DWV1724_Header_TriggerTimeTag_Mask ) >> DWV1724_Header_TriggerTimeTag_Shift;
  } else {
    return 0;
  }
}

int16_t MDpartEventV1724::GetSampleData( unsigned short aChannel , unsigned long aSample ) {
  if ( aChannel >= V1724_NCHANNELS ) return 0;
  if ( aSample >= GetLength(aChannel)*2 ) return 0;
  MDdataWordV1724 dw1724;
  if ( _sequence[aChannel] ) {
    dw1724.SetDataPtr( &_sequence[aChannel][aSample/2] );
    if ( dw1724.IsValid() ) return dw1724.GetSample(aSample%2);
  }
  return 0;
}

void MDpartEventV1724::Dump(int atTheTime){
  cout << *this;

  return;
} 

////////////////////////////////////////////////////////////////////////

ostream &operator<<(ostream &s,MDpartEventV1724 &dw){
  MDdataWordV1724 dw1724;

  s << showbase << hex;
  s << " ------------   CAEN V1724 Header    ------------ " << endl ; 
  s << " Word Count        : " << dec << dw.GetWordCount() << endl;
  s << " Geo               : " << dw.GetGeo() ;
  if ( dw.GetZLE() ) s << " ; ZLE enabled" ;
  else s << " ; ZLE disabled" ;
  s << " ; Channel Mask : "    << showbase << hex << dw.GetChannelMask() << endl;
  s << " Event Counter     : " << dec << dw.GetEventCounter() << endl;
  s << " Trigger Time Tag  : " << dw.GetTriggerTimeTag() << endl;
  s << " ------------ End of CAEN V1724 Header ----------- " << endl ; 

  //  unsigned int nSamplePerChannel = 512;
  //  unsigned int nWordPerChannel   = nSamplePerChannel/2 ; // two samples per word
 
  
  if ( dw.GetZLE() == 0 ) {
    unsigned int expectWordCount( dw.GetNChannels()* dw.GetLength(0) + V1724_HEADER_WORDS );
    if ( expectWordCount != dw.GetWordCount() ) {
      s << " *** ERROR in CAEN V1724 data format: Word count is not consistent *** " << endl ; 
    }
    
    for (unsigned int ch=0; ch < V1724_NCHANNELS ; ch++) {
      s << " ----------   Channel " << dec << ch << " ( Length = " << dw.GetLength(ch) << " ) ---------- " << endl ; 
      for ( unsigned int iw=0; iw <dw.GetLength(ch) ; iw++ ) {
	unsigned int iww = ch * dw.GetLength(ch) + iw;
	unsigned int* ptr = dw.Get32bWordPtr(V1724_HEADER_WORDS + iww );
	dw1724.SetDataPtr(ptr);
	dw1724.Dump() ;
      }
    }
    /*
    //  Exemple for using MDpartEventV1724::GetSampleData();
    cout << " ****** Alternative dump ****** " << endl;
    for (unsigned int ch=0; ch < V1724_NCHANNELS ; ch++) {
      cout << " AD ------- Channel " << dec << ch << " ( Length = " << dw.GetLength(ch) << " ) -------- " << endl ; 
      for (unsigned int s=0; s < dw.GetLength(ch)*2 ; s++) {
	cout << dw.GetSampleData(ch,s) << " ; " ;
	if ((s+1)%8 == 0) cout << endl;
      }
    }
    */

  } else {
    s << " Decoding with Zero Supression not yet implemented " << endl;
  }
  return s;
}

