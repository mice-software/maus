/***************************************************************************
 *                                                                         *
 * $Log: MDpartEventV1290.cpp,v $
 * Revision 1.3  2009/04/21 12:39:29  daq
 * Introduce Trigger Time Tag and Bunch ID
 *
 * Revision 1.2  2008/04/29 07:35:02  daq
 * Add {} for switch cases for better portability.
 *
 * Revision 1.1  2008/04/14 11:40:45  daq
 * Initial revision
 *
 * Revision 1.5  2008/04/11 10:26:20  daq
 * Remove cout of error in case an empty MDpartEventV1290 object is created.
 *
 * Revision 1.4  2008/04/10 11:10:02  daq
 * Debug GetNHits to allow TDC errors.
 * Implement GetHitMeasurement() accordingly.
 *
 * Revision 1.3  2008/04/08 14:00:08  daq
 * Introduce vector of Hits (leading edge and trailing edge).
 * Implement GetNHitsPerChannel(unsigned int ich,char t).
 * ich = channel number
 * t = measurement type ( 'l' for leading edge [default] or 't' for trailing edge.
 *
 * Revision 1.2  2008/01/30 14:55:32  daq
 * Introduce user friendly functions for unpacking, like GetHitMeasurement(int)
 * See example in Dump() method
 *
 * Revision 1.1  2008/01/25 10:14:02  daq
 * Initial revision
 *
 *                                                                         *
 * Originally created by J.S. Graulich December 2007                       *
 *                                                                         *
 ***************************************************************************/

#include "MDpartEventV1290.h"

MDpartEventV1290::MDpartEventV1290(void *d):MDdataContainer(d),_wordCount(0),_geo(0),_triggerTimeTag(0){ 
  Init();
}

void MDpartEventV1290::Init(){
  unsigned int * ptr = Get32bWordPtr(0);
  unsigned int unit(0);
  MDdataWordV1290 dw(ptr);
  UnValidate();
  _wordCount = 0 ;
  for (int ich=0 ; ich < V1290_NCHANNELS ; ich++) {
    _nLeadingEdgeHits[ich]=0;
    _nTrailingEdgeHits[ich]=0;
    _leadingEdgeHit[ich].clear();
    _trailingEdgeHit[ich].clear();
  }
   _nLeadingEdgeHits[V1290_NCHANNELS]=0;
   _nTrailingEdgeHits[V1290_NCHANNELS]=0;
  if ( dw.IsValid() ) {
    if ( dw.GetDataType() == DWV1290_GlobalHeader ) {
      _geo = dw.GetGeo();
      _wordCount++;
      dw.SetDataPtr(++ptr);
      while ( dw.GetDataType() != DWV1290_GlobalTrailer) {
	switch ( dw.GetDataType() ) {
	case DWV1290_Measurement: 
	  { // Normal case
	    // Fill the hit vectors, depending on the measurement type
	    int theCh = dw.GetChannel();
	    _unitWordCount++;
	    switch( dw.GetMeasurementType() ){
	    case DWV1290_TrailingMeas:
	      {
		_nTrailingEdgeHits[V1290_NCHANNELS]++;
		_nTrailingEdgeHits[theCh]++;
		_trailingEdgeHit[theCh].push_back(dw.GetMeasurement());
		break;
	      }
	    case DWV1290_LeadingMeas:
	      {
		_nLeadingEdgeHits[V1290_NCHANNELS]++;
		_nLeadingEdgeHits[theCh]++;
		_leadingEdgeHit[theCh].push_back(dw.GetMeasurement());
		break;
	      }
	    default: 
	      {
		cout << "WARNING in MDpartEventV1290::Init(): "
		     << "Unknown V1290 Measurement Type. "
		     << "Trying to ignore... " << endl;
		cerr << "WARNING in MDpartEventV1290::Init(): "
		     << "Unknown V1290 Measurement Type. "
		     << " Trying to ignore... " << endl;
		break;
	      }
	    }
	    break;
	  }
	case DWV1290_TdcHeader:
	  {
	    unit =  dw.GetTdc();
	    _bunchID[unit]= dw.GetBunchID();
	    _eventID[unit]= dw.GetEventID();
	    _unitWordCount = 1;
	    break;
	  }
	case DWV1290_TdcTrailer:
	  {
	    _unitWordCount++;
	    //	    if ( _unitWordCount != dw.GetWordCount() ||
	    // It happens sometimes that the TDC error comes after the trailer
	    // but is still counted as a word
	    if (  _eventID[unit] != dw.GetEventID()
		 || unit !=  dw.GetTdc() ) {
	    cout << "WARNING in MDpartEventV1290::Init: " 
		 << "TDC trailer is not consistent" << endl;
	    cout << _unitWordCount <<  " != " << dw.GetWordCount() 
		 << " || " << _eventID[unit] << " != " << dw.GetEventID()
		 << " || " << unit << " != " <<  dw.GetTdc() << endl;
	    }
	    break;
	  }
	case DWV1290_TdcError:
	  { 
	    _unitWordCount++;
	    cout << "WARNING in MDpartEventV1290::Init: " 
		 << "Unexpected TDC Error" << endl;
	    break;
	  }
	case DWV1290_TriggerTimeTag:
	  {
	    _unitWordCount++;
	    _triggerTimeTag = dw.GetTriggerTimeTag();
	    break;
	  }
	case DWV1290_Filler:
	  {
	    cout << "WARNING in MDpartEventV1290::Init: "
		 << "Unexpected Data Filler" << endl;
	    break;
	  }
	default:
	  {
	    cout << " ERROR in MDpartEventV1290::Init: "
		 << "Unknown data Type !" << endl 
		 << " Data value : " << hex << showbase << *ptr << endl
		 << " It looks like there is a global trailer missing " << endl
		 << " That is serious error. Call the expert" << endl;
	    cerr << " ERROR in MDpartEventV1290::Init: "
		 << "Unknown data Type !" << endl 
		 << " Data value : " << hex << showbase << *ptr << endl
		 << " It looks like there is a global trailer missing " << endl
		 << " That is serious error. Call the expert" << endl;

	    break;
	  }
	}
	_wordCount++;
	dw.SetDataPtr(++ptr);
      }
      if ( dw.GetDataType() == DWV1290_GlobalTrailer ) {
	_wordCount++;
	if ( _wordCount == dw.GetWordCount() && _geo == dw.GetGeo()) {
	  Validate();
	  SetSize( _wordCount*4 );
	  _tdcStatus = dw.GetStatus();
	} else cout << "ERROR in MDpartEventV1290::Init: Word count not consistent" << endl;
      }
    } else cout << "ERROR in MDpartEventV1290::Init: 1st word is not global header" << endl;
  } 
}
unsigned int MDpartEventV1290::GetBunchID(unsigned int unit)
{
  if (unit<4) {
    return _bunchID[unit];
  } else {
    return (_bunchID[0]+_bunchID[1]+_bunchID[2]+_bunchID[3])/4;
  }

}

void MDpartEventV1290::SetDataPtr( void *d ) 
{
  MDdataContainer::SetDataPtr(d);
  Init();
}

unsigned int MDpartEventV1290::GetEventCount()
{
  if (IsValid()) {
    MDdataWordV1290 dw( Get32bWordPtr(0) );
    return dw.GetEventCount();
  } else {
    return 0;
  }
}

unsigned int MDpartEventV1290::GetWordCount(){
  if (IsValid()) {
    return _size/4;
  } else {
    return 0;
  }
}

unsigned int MDpartEventV1290::GetStatus(){
  if (IsValid()) {
    return _tdcStatus;
  } else {
    return 0;
  }
}

unsigned int MDpartEventV1290::GetNHits(unsigned int ich,char t){
  unsigned int nh(0);
  if ( ich>V1290_NCHANNELS ) {
    cerr << "ERROR in MDpartEventV1290::GetNHits(): Wrong argument: ch = " << ich << endl;
    return 0;
  }
  switch(t){
  case 'a':
    {
      nh = _nLeadingEdgeHits[ich] + _nTrailingEdgeHits[ich] ;
      break;
    }
  case 'l':
    {
      nh = _nLeadingEdgeHits[ich];
      break;
    }
  case 't':
    {
      nh = _nTrailingEdgeHits[ich];
      break;
    }
  default:
    {
      cerr << "ERROR in MDpartEventV1290::GetNHits(): Wrong argument: t = " << t << endl;
      break;
    }
  }
  return nh;
} 

unsigned int  MDpartEventV1290::GetHitMeasurement(unsigned int ih, unsigned int ich, char t){
  int rv = 0xFFFFFFFF ;
  if ( ich>V1290_NCHANNELS-1 ) {
    cerr << "ERROR in MDpartEventV1290::GetHitMeasurement(): "
	 << "Wrong argument: ch = " << ich << endl;
    return rv;
  }
 switch(t){
  case 'l':
    {
      if (ih<_nLeadingEdgeHits[ich]) rv = _leadingEdgeHit[ich][ih];
      else cerr << "ERROR in MDpartEventV1290::GetHitMeasurement(): "
		<< "Wrong argument: ih = " << ih << endl;
      break;
    }
  case 't':
    { 
      if (ih<_nTrailingEdgeHits[ich]) rv = _trailingEdgeHit[ich][ih];
      else cerr << "ERROR in MDpartEventV1290::GetHitMeasurement(): "
		<< "Wrong argument: ih = " << ih << endl;
      break;
    }
  default:
    {
      cerr << "ERROR in MDpartEventV1290::GetNHits(): "
	   << "Wrong argument: t = " << t << endl;
      break;
    }
  }
  return rv;
}

void MDpartEventV1290::Dump(int atTheTime){
  if (IsValid()) {
    unsigned int wc(0);
    unsigned int * ptr = Get32bWordPtr( 0 );
    MDdataWordV1290 dw(ptr) ;
    while (wc < GetWordCount() ) {
      cout << dw;
      dw.SetDataPtr( ++ptr );
      wc++;
    }    
    // Alternative method follows (more appropriate example for unpacking applications)
    // (TDC errors are not printed out)

    /*
    cout << " TDC V1290 Particle Event: Event Count: " << dec << GetEventCount() 
	 << " Geo Address: " << GetGeo() << " Word Count: " << GetWordCount() <<endl;
    cout << " Total number of hits: " << GetNHits() << endl;
    for ( unsigned int ich=0; ich <V1290_NCHANNELS ; ich++) {
      cout << " Total number of hits in channel: " << ich << " : " 
           << GetNHits(ich) << endl;
      cout << " Leading edge: " << GetNHits(ich,'l') 
           << " , Trailing edge: " << GetNHits(ich,'t') << endl; 
      for ( unsigned int ih=0; ih < GetNHits(ich,'l') ; ih++) {
	cout << " Channel: " << dec << ich << " ;  Hit: " << ih 
	     << " : " << GetHitMeasurement(ih,ich,'l') ;
	cout << " (Leading Edge)" ;
	cout << endl;
      }
      for ( unsigned int ih=0; ih < GetNHits(ich,'t') ; ih++) {
	cout << " Channel: " << dec << ich << " ;  Hit: " << ih 
	     << " : " << GetHitMeasurement(ih,ich,'t') ;
	cout << " (Trailing Edge)" ;
	cout << endl;
      }
    }
    */
  } else {
    cout << "**** ERROR: INVALID CAEN TDC V1290 Particle Event ****" << endl;
  }
  return;
} 

////////////////////////////////////////////////////////////////////////


