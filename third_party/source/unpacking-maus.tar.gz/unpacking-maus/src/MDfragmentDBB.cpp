#include "MDfragmentDBB.h"

void MDfragmentDBB::SetDataPtr( void *d, uint32_t aSize=0 ) {
  MDfragment::SetDataPtr(d, aSize);
}

void MDfragmentDBB::Init(){
  uint32_t* ptr = Get32bWordPtr(0);
  MDdataWordDBB dw(ptr);
  UnValidate();
  //   cout << " Calling MDfragmentDBB::Init() " << endl;
  for (int ich=0 ; ich < DBB_NCHANNELS ; ich++) {
    _nLeadingEdgeHits[ich]=0;
    _nTrailingEdgeHits[ich]=0;
    _leadingEdgeHit[ich].clear();
    _trailingEdgeHit[ich].clear();
  }
  _madeOfParticles = false;
  if ( dw.IsValid() ) {
    // Check the reliability of the header and decode the header information.
    if (dw.GetDataType() != MDdataWordDBB::Header ){ // The data doesn't start with a header
      cout << "WARNING in MDfragmentDBB::Init: 1st word is not a header" << endl;
      throw MDexception("ERROR in MDframentDBB::Init() : 1st word is not a header ***", MDexception::WARNING) ;
    } else {
      _headerSize = DBB_HEADER_WORDS*WORD_SIZE;
      _trailerSize = DBB_TRAILER_WORDS*WORD_SIZE;
      _payLoadSize = GetSize() - _headerSize -  _trailerSize;
      _header = ptr;
      _boardID = dw.GetGeo();
      _spillNum = dw.GetSpillNumber();
      dw.SetDataPtr( ++ptr );
      _triggerCount = dw.GetTriggerCount();
      _hitCount = dw.GetHitCount() ;
/*
      if ( (_hitCount*WORD_SIZE*2 - _payLoadSize) > 1 ) { // May not be always false, we can miss some trailing ege hits...
        cout << "ERROR in MDfragmentDBB()::Init(): Number of words : ";
        cout << _payLoadSize/WORD_SIZE << "  expected : " << _hitCount*2 << endl;
      }
*/
      _payLoad = _header + _headerSize/WORD_SIZE;
      _trailer = _payLoad + _payLoadSize/WORD_SIZE;
    }
    // Check the reliability of the trailer and decode the trailer information.
    ptr = _trailer;
    dw.SetDataPtr( ptr );
    if ( dw.IsValid() ) {
      if (dw.GetDataType()    != MDdataWordDBB::Trailer ||
          dw.GetGeo()         != _boardID      || //temporary disable this for debugging
          dw.GetSpillNumber() != _spillNum     ||
          dw.GetStatus() ){// The data doesn't end with a proper header
        cout << "WARNING in MDfragmentDBB::Init: DBB Trailer is not consistent" << endl;
        throw MDexception("ERROR in MDframentDBB::Init() : DBB trailer is not consistent ***", MDexception::WARNING) ;
      } else {
        dw.SetDataPtr( ++ptr );
        _spillWidth = dw.GetSpillWidth();
      }
    } else {
      throw MDexception("ERROR in MDframentDBB::Init() : DBB trailer is not valid ***", MDexception::FATAL) ;
    }

    // Decode the payload.
    ptr = _payLoad;
    while(ptr != _trailer){
      dw.SetDataPtr( ptr++ ); // don't need to check that the word is valid here since we know the trailer is valid
      unsigned int theCh = dw.GetChannelId();
      unsigned int theTime = dw.GetHitTime();
      switch( dw.GetDataType() ){
        case MDdataWordDBB::TrailingMeas:
        {
          _nTrailingEdgeHits[ DBB_NCHANNELS ]++;
          _nTrailingEdgeHits[ theCh ]++;
          _trailingEdgeHit[ theCh ].push_back( theTime );

          break;
        }
        case MDdataWordDBB::LeadingMeas:
        {
          _nLeadingEdgeHits[ DBB_NCHANNELS ]++;
          _nLeadingEdgeHits[ theCh ]++;
          _leadingEdgeHit[ theCh ].push_back( theTime );
          //if( _testCallBack )
            //_testCallBack( dw.GetMeasurement() );
          break;
        }
        default:
        {
          throw MDexception("ERROR in MDframentDBB::Init() : Unexpected identifier ***", MDexception::FATAL) ;
        }
      }
    }
    Validate();
  }
}

void MDfragmentDBB::Dump( int atTheTime )
{
  if (IsValid()) {
    cout << "**** DBB  ****" << endl;
    cout << "Board Id      : " << _boardID << endl;
    cout << "Spill Num     : " << _spillNum << endl;
    cout << "Trigger Count : " << _triggerCount << endl;
    cout << "Hit Count     : " << _payLoadSize << endl;
    cout << "Spill Width   : " << _spillWidth << endl;
    uint32_t* ptr = _payLoad;
    while(ptr != _trailer) {
      MDdataWordDBB dw( ptr++ );
      long32 dt= dw.GetDataType();
      switch(dt){
      case  MDdataWordDBB::LeadingMeas:
	cout << "Leading edge Measurement : ";
	break;
      case  MDdataWordDBB::TrailingMeas:
	cout << "Trailing edge Measurement : ";
	break;
      default:
	cout << "Invalid Measurement!";
	return;
	break;
      }
      cout<< dw.GetHitTime() <<" ; channel : "<< dw.GetChannelId() <<endl;
    }
  }
}

unsigned int  MDfragmentDBB::GetHitMeasurement(unsigned int ih, unsigned int ich, char t){
  int rv = 0xFFFFFFFF ;
  if ( ich>DBB_NCHANNELS-1 ) {
    cerr << "ERROR in MDfragmentDBB::GetHitMeasurement(): "
	 << "Wrong argument: ch = " << ich << endl;
    return rv;
  }
 switch(t){
  case 'l':
    {
      if (ih<_nLeadingEdgeHits[ich]) { rv = _leadingEdgeHit[ich][ih]; }
      else cerr << "ERROR in MDfragmentDBB::GetHitMeasurement(): "
		<< "Wrong argument: ih = " << ih << endl;
      break;
    }
  case 't':
    {
      if (ih<_nTrailingEdgeHits[ich]) rv = _trailingEdgeHit[ich][ih];
      else cerr << "ERROR in MDfragmentDBB::GetHitMeasurement(): "
		<< "Wrong argument: ih = " << ih << endl;
      break;
    }
  default:
    {
      cerr << "ERROR in MDfragmentDBB::GetNHits(): "
	   << "Wrong argument: t = " << t << endl;
      break;
    }
  }

  return rv;
}

