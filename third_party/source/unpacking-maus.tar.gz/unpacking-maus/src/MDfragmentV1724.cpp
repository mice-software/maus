/***************************************************************************
 *                                                                         *
 * Originally created by J.S. Graulich May 2011                            *
 *                                                                         *
 ***************************************************************************/

#include "MDfragmentV1724.h"

MDfragmentV1724::MDfragmentV1724(void *d):MDfragment(d){ 
  // A fragment should be created only once inside the map
  //  cout << " Creating a MDfragmentV1724 ..." << endl; 
  //  cout << hex << d << dec << endl;  // both should be equal to 0 

  _partEventPtr = new MDpartEventV1724(0);
  Init();
}

void MDfragmentV1724::SetDataPtr( void *d, uint32_t aSize ) {
  MDfragment::SetDataPtr(d, aSize);
}

void MDfragmentV1724::Init(){
  uint32_t * ptr = Get32bWordPtr(0);
  MDdataWordV1724 dw(ptr);
  //  cout << " Executing MDfragmentV1724::Init() ..." << endl; 
  UnValidate();
  _madeOfParticles = true;

  if ( dw.IsValid() ) {
   // TODO : Basic checks on the data consistency
    Validate();
    //  } else {
    //    cout << " Error in MDfragmentV1724::Init() : first data word not valid " << endl;
    //   if (ptr) cout  << showbase << hex <<  ptr[0] << dec << endl;
  }

  //  cout << "  ... Done with MDfragmentV1724" << endl; 
}

////////////////////////////////////////////////////////////////////////


