/***************************************************************************
 *                                                                         *
 * $Log: MDdataWordV1731.cpp,v $
 * Revision 1.1  2009/04/21 12:36:12  daq
 * Initial revision
 *
 *                                                                         *
 * Originally created by J.S. Grulich, Dec 2008                            *
 *                                                                         *
 ***************************************************************************/

#include "MDdataWordV1731.h"

MDdataWordV1731::MDdataWordV1731(void *d):MDdataWord(d) {
}

void MDdataWordV1731::Dump(int atTheTime){
  cout << *this;
  return;
} 

////////////////////////////////////////////////////////////////////////

ostream &operator<<(ostream &s,MDdataWordV1731 &dw){
//long32 dt = dw.GetDataType();
  if (  !dw.IsValid() ) {
    s << " INVALID ( " << showbase << hex << dw.Get32bWordPtr()[0] << " ) " ;
  }
  s << " CAEN V1731 Data: " << dec 
    << dw.GetSample(0) << " ; " <<  dw.GetSample(1) << " ; " 
    << dw.GetSample(2) << " ; " <<  dw.GetSample(3) << endl; 
  s << dec << noshowbase;
  return s;
}

