/***************************************************************************
 *                                                                         *
 * $Log: MDequipMap.cpp,v $
 * Revision 1.3  2009/04/21 12:37:21  daq
 * Introduce V1731 and PCI6254
 *
 * Revision 1.2  2008/04/29 07:38:12  daq
 * Implement Dump() and GetType() functions.
 *
 * Revision 1.1  2008/04/14 11:40:45  daq
 * Initial revision
 *
 * Revision 1.1  2008/01/25 10:03:51  daq
 * Initial revision
 *
 *
 * Originally created by J.S. Graulich january 2008                        *
 *                                                                         *
 ***************************************************************************/

#include "MDequipMap.h"
#include "MDfragment.h"
#include "MDfragmentV1290.h"
#include "MDfragmentV1724.h"
#include "MDfragmentV830.h"
#include "MDfragmentDBB.h"
#include "MDfragmentV1731.h"
#include "MDfragmentVLSB_C.h"

int MDequipMap::_count = 0;
equipMap_t MDequipMap::_equipMap;

MDequipMap::MDequipMap()
{
  if (MDequipMap::_count++ == 0) {
    cout << " Creating the equipment map ..." << endl;
    ADD_EQUIP_IN_MAP(111,V830);
    ADD_EQUIP_IN_MAP(102,V1290);
    ADD_EQUIP_IN_MAP(121,V1731);
    ADD_EQUIP_IN_MAP(120,V1724);
    ADD_EQUIP_IN_MAP(141,DBB);
    ADD_EQUIP_IN_MAP(80,VLSB_C);

    SetEquipmentTypes();
    Dump();
  } else {
    cerr << "WARNING in MDequipMap::MDequipMap() : Trying to create a multiple instances of a static singleton class" << endl;
    Dump();
  }
}

MDequipMap::~MDequipMap(){
    // delete fragments and descriptors
  if (MDequipMap::_count != 0) {
    equipMap_t::iterator it=_equipMap.begin();
    for (unsigned int i=0; i < _equipMap.size(); i++,it++) {
      delete (it->second)->GetFragmentPtr();
      delete (it->second);
    }
    _count = 0;
  }
}


void  MDequipMap::SetEquipmentTypes(){
  equipMap_t::iterator it=_equipMap.begin();
  //  cout << " Setting Equipment types..." << endl;
  for (unsigned int i=0; i < _equipMap.size(); i++,it++) {
    (it->second)->GetFragmentPtr()->SetEquipmentType(it->first);
  }
  //    cout << " ... Done with Equipment types" << endl;

}

unsigned int MDequipMap::GetType( string name )
{
  if (_count) {
    equipMap_t::iterator it=_equipMap.begin();
    for (unsigned int i=0; i < _equipMap.size(); i++,it++) {
      if ( (it->second)->GetName() == name ) return it->first;
    }
  }
  return 0;
}

void MDequipMap::Dump()
{
	cout << " --- Equipment Map Dump --- " << endl;
  equipMap_t::iterator it=_equipMap.begin();
  for (unsigned int i=0; i < _equipMap.size(); i++) {
    cout << dec << it->first << " " << hex << showbase << it->second << " "
	 << (it->second)->GetName() << " " << (it->second)->GetDataContainerPtr() << dec << noshowbase << endl;
    it++;
  }
  cout << "Equipment Map count : " << MDequipMap::_count << endl;
}

MDdataContainer* MDequipDesc::GetDataContainerPtr(){return (MDdataContainer*) dcPtr;}
