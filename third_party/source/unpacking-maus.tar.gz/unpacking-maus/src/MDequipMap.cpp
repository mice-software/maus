/***************************************************************************
 *                                                                         *
 * $Log: MDequipMap.cpp,v $
 * Revision 1.3  2009/04/21 12:37:21  daq
 * Introduce V1731 and PCI6254
 *
 * Revision 1.2  2008/04/29 07:38:12  daq
 * Implement Dump() and GetType() functions.
 *
 * Revision 1.1  2008/04/14 11:40:45  daq
 * Initial revision
 *
 * Revision 1.1  2008/01/25 10:03:51  daq
 * Initial revision
 *
 *
 * Originally created by J.S. Graulich january 2008                        *
 *                                                                         *
 ***************************************************************************/

#include "MDequipMap.h"

int MDequipMap::_count = 0;
equipMap MDequipMap::_equipMap;

MDequipMap::MDequipMap()
{
  if (MDequipMap::_count++ == 0) {
    ADD_EQUIP_IN_MAP(111,V830);
    ADD_EQUIP_IN_MAP(102,V1290);
    ADD_EQUIP_IN_MAP(120,V1724);
    ADD_EQUIP_IN_MAP(121,V1731);
    ADD_EQUIP_IN_MAP(128,PCI6254);

    //Dump();
  }
}

unsigned int MDequipMap::GetType( string name )
{
  equipMap::iterator it=_equipMap.begin();
  for (unsigned int i=0; i < _equipMap.size(); i++,it++) {
    if ( (it->second)->GetName() == name ) return it->first;
  }
  return 0;
}

void MDequipMap::Dump()
{
  equipMap::iterator it=_equipMap.begin();
  for (unsigned int i=0; i < _equipMap.size(); i++) {
    cout << dec << it->first << " " << hex << showbase << it->second << " "
	 << (it->second)->GetName() << " " << (it->second)->GetDataContainerPtr() << endl;
    it++;
  } 
 cout << "Equipment Map count : " << MDequipMap::_count << endl;
}
