/***************************************************************************
 *                                                                         *
 * $Log: MDpartEventV830.cpp,v $
 * Revision 1.2  2009/04/21 12:41:30  daq
 * Debug Unpacking
 *
 * Revision 1.1  2008/04/14 11:40:45  daq
 * Initial revision
 *
 * Revision 1.1  2008/01/25 10:14:02  daq
 * Initial revision
 *
 *                                                                         *
 * Originally created by J.S. Graulich December 2007                       *
 *                                                                         *
 ***************************************************************************/

#include "MDpartEventV830.h"

MDpartEventV830::MDpartEventV830(void *d):MDdataContainer(d),_geo(0),_wordCount(1),_ts(0xFFFF),_triggerCount(0){ 
  Init();
}

void MDpartEventV830::SetDataPtr( void *d ) {
  MDdataContainer::SetDataPtr(d);
  Init();
}

void MDpartEventV830::Init(){
  unsigned int * ptr = Get32bWordPtr(0);
  MDdataWordV830 dw(ptr);
  UnValidate();
  if ( dw.IsValid() ) {
    if (dw.GetDataType() == DWV830_Header ){
      _geo = dw.GetGeo();
      _wordCount = dw.GetWordCount() + 1;// the header is not included in the word count
      _ts = dw.GetTriggerType();
      _triggerCount = dw.GetTriggerCount();
      SetSize(_wordCount*4);
    } else { // The data doesn't start with a header
      cout << "WARNING in MDpartEventV830::Init: 1st word is not a header" << endl;
    }
    Validate();
  }
}

unsigned int MDpartEventV830::GetChannel(unsigned int iw)
{
  if (iw < GetWordCount() -1 ) {
    unsigned int * ptr = Get32bWordPtr(iw+1);
    MDdataWordV830 dw(ptr);
    return dw.GetChannel();
  } else {
    return 0xFFFFFFFF;
  }
}

unsigned int MDpartEventV830::GetMeasurement(unsigned int iw)
{
  if (iw < GetWordCount() -1 ) {
    unsigned int * ptr = Get32bWordPtr(iw+1);
    MDdataWordV830 dw(ptr);
    return dw.GetMeasurement();
  } else {
    return 0xFFFFFFFF;
  }
}

void MDpartEventV830::Dump(int atTheTime)
{
  if (IsValid()) {
    cout << "**** CAEN V830  ****" << endl;
    unsigned int wc(0);
    unsigned int * ptr = Get32bWordPtr( 0 );
    MDdataWordV830 dw(ptr) ;
    while (wc < GetWordCount() ) {
      cout << dw ;
      dw.SetDataPtr( ++ptr );
      wc++;
    }  
  }
  return;
} 

////////////////////////////////////////////////////////////////////////


