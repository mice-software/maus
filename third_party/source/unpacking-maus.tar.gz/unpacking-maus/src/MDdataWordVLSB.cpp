/***************************************************************************
 *                                                                         *
 *                                                                         *
 * Originally created by J.S. Graulich, May 2011                           *
 *                                                                         *
 ***************************************************************************/

#include "MDdataWordVLSB.h"

MDdataWordVLSB::MDdataWordVLSB(void *d):MDdataWord(d){}

bool   MDdataWordVLSB::IsValid(){
  if (!_data) return false;
  if (Get32bWordPtr()[0]==MDdataWordVLSB::Error_Word) return false;
  //  if ((Get32bWordPtr()[0] & MDdataWordVLSB::Adc_Mask) == 0) return false; // the bank length word can also be a valid word.
  return true;
}

void MDdataWordVLSB::Dump(int atTheTime){
  cout << *this;
  return;
} 

////////////////////////////////////////////////////////////////////////

ostream &operator<<(ostream &s,MDdataWordVLSB &dw){
  s << " VLSB Word : ";
  if (dw.IsValid()) {
    s << "Event: " << dw.GetEventNum() << " ; Channel: " << dw.GetChannel() 
      << " ; Adc: " << dw.GetAdc() ;
    if (dw.GetDiscriBit()) {
      s << " (over thr) ";
    } else {
      s << " (under thr) ";
    }
    s << " ; Tdc: " << dw.GetTdc() << endl ;
  } else {
    s << "INVALID : " << showbase << hex << dw.Get32bWordPtr()[0] << ")" << dec << noshowbase << endl;  
  }
  return s;
}

