
/***************************************************************************
 * EMR Test with Calibration events                                        *
 *                                                                         *
 * Originally created by J.S. Graulich May 2011                            *
 *                                                                         *
 ***************************************************************************/

#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <typeinfo>
#include <exception>

#include "MDprocessManager.h"
#include "MDevent.h"
#include "event.h"
#include "MDdateFile.h"
#include "MDfileManager.h"
#include "MDargumentHandler.h"
#include "MDfragmentDBB.h"

#include "TROOT.h"
#include "TFile.h"
#include "TH1I.h"
#include "TNtuple.h"

using namespace std;

// Create a MDprocessor daughter class for each data structure to be analysed.
// In this example, all the classes are declared and defined in the same file
// but for real applications, C++ good practice is to have one .h and one .cpp
// file per class.

class OnStartOfRun : public MDprocessor {
 public:
  OnStartOfRun():MDprocessor(){}
  virtual ~OnStartOfRun(){}
  virtual int Process(MDdataContainer*);
};

int OnStartOfRun::Process(MDdataContainer* aEvtPtr){
  cout << "Starting run " << GetRunNumber() << " on " <<  GetTimeString() << endl;
  return OK;
}
/////////////////////////////////////////////////////////////////

class OnEventHeader : public MDprocessor {
  public:
  OnEventHeader( vector<uint32_t> &aVect):MDprocessor(),myEventCount(&aVect){}
  virtual ~OnEventHeader(){}
  virtual int Process(MDdataContainer*);

  vector<uint32_t> * myEventCount;

};

int OnEventHeader::Process(MDdataContainer* aEvtPtr){
  // cast the argument to structure it points to
  // This process should be called only with MDevent argument corresponding to LDC event
  if ( typeid(*aEvtPtr) != typeid(MDevent) ) return CastError;
  MDevent* theEvent = static_cast<MDevent*>(aEvtPtr);

  // open input file

  if (theEvent->EventType() == CALIBRATION_EVENT) { ((*myEventCount)[theEvent->LdcId()])++;}

  return OK;
}

//********* OnFragmentDBB **************
// In this example, useful for EMR Calibration data

class OnFragmentDBB : public MDprocessor {
  public:
  OnFragmentDBB(vector<uint32_t> &aVect, TNtuple * aNt):MDprocessor(),myEventCount(&aVect),ntuple(aNt){}
  virtual ~OnFragmentDBB(){}
  virtual int Process(MDdataContainer*);

  ostream* myObj;
  vector<uint32_t> * myEventCount;
  TNtuple * ntuple;

};

int OnFragmentDBB::Process(MDdataContainer* aFragPtr){
  // cast the argument to structure it points to
  if ( typeid(*aFragPtr) != typeid(MDfragmentDBB) ) return CastError;
  MDfragmentDBB* theFrag = static_cast<MDfragmentDBB*>(aFragPtr);
  cout << " In " << MDequipMap::GetName(GetEquipmentType()) ;
  cout << " board # " << GetBoardId() << endl;

  if (theFrag->IsValid()) {
    if ( GetEventType() == CALIBRATION_EVENT ){
      // print context
      // print bank lengths
      cout << " LDC ID : " << GetLdcId() << endl ;
      cout << " Spill Number : " << (*myEventCount)[GetLdcId()] << endl ;

      // do some particle event building here

      // print unpacked channel and adc data




      MDdataWordDBB dw;
      uint32_t * dataPtr=theFrag->UserPayLoadPtr();
      for (unsigned int iw=0; iw<theFrag->GetPayLoadWordCount(); iw++){
	dw.SetDataPtr(dataPtr);
	cout << "Channel : " << dw.GetChannelId() ;
	if (  dw.GetDataType() == MDdataWordDBB::TrailingMeas ) {
	  cout << " ; Trailing Edge ";
	} 
	else if ( dw.GetDataType() == MDdataWordDBB::LeadingMeas ){
	  cout << " ; Leading Edge ";
	}
	else {
	  cout << " ; Unvalid ";
	}
	cout << " Time : " << dw.GetHitTime() << endl;
	dataPtr++;
	// ntuple->Fill(GetLdcId(),(*myEventCount)[GetLdcId()],iban,dw.GetEventNum(),dw.GetChannel(),dw.GetAdc());
     }
    }
  }
  return OK;
}

/* Application main */
int main( int argc, char **argv ) {
  string stringBuf;
  string fileName;
  string pathName;

  // The following shows how to use the MDargumentHandler class
  // to deal with the main arguments
  // Define the arguments
  MDargumentHandler argh("Example of unpacking application.");
  argh.AddArgument("help","print this message","h");
  argh.AddArgument("directory","path for the data file","d","<string>","/home/daq/Downloads" );
  argh.AddArgument("file","list of file names or run numbers (space separated within double quotes)","f","<string>","mandatory");
  // Check the user arguments consistancy
  // All mandatory arguments should be provided and
  // There should be no extra arguments
  if ( argh.ProcessArguments(argc,argv) ) { argh.Usage(); return -1; }

  // Treat arguments, obtain values to be used later
  if ( argh.GetValue("help") ) { argh.Usage(); return 0; }
  if ( argh.GetValue("directory",pathName) != MDARGUMENT_STATUS_OK ) return -1;
  cout << "Directory : " << pathName << endl;
  if ( argh.GetValue("file",fileName) != MDARGUMENT_STATUS_OK ) return -1;
  cout << "Files : " << fileName << endl;

  // Event counter (one per forseen LDC)
  vector<uint32_t> myEventCount(3);

  // Root file and Tree
  TFile* rootFile = new TFile("Test.root", "RECREATE"); 
  TNtuple *ntuple = new TNtuple("ntuple","Tracker Cosmics Test","ldcId:eventNb:vrbId:dbbId:chId:leTime:teTime");
  // Declare the process Manager. This is mandatory ! 
  MDprocessManager thePM;
	
  // Declare and define the processors with their target objects and parameters
  OnStartOfRun*   sorProc = new OnStartOfRun();
  OnFragmentDBB*  dbbProc = new OnFragmentDBB(myEventCount,ntuple);
  OnEventHeader*  eventHeaderProc = new OnEventHeader(myEventCount);

  // Set the user processors  cout << "Equipment Map count : " << MDequipMap::_count << endl;

  thePM.SetStartOfRunProc(sorProc);  // The ProcessManager will execute
                                     // sorProc->Process(&theEvent) each time a new
                                     // start of run event is found in the file
  thePM.SetEventHeaderProc(eventHeaderProc);  
	thePM.SetFragmentProc("DBB",dbbProc); // for fragments and particle events, the equipment name must be specified

  thePM.DumpProcessors();
	MDequipMap::Dump();
  // Disable equipments that should not be decoded (in case of internal format error).
  // If an equipment is disabled, it is skipped at the equipment header level.
  thePM.Disable("V1731");

  // Declare the DATE data file handler
  MDfileManager dFileManager(fileName,pathName);
  if ( dFileManager.OpenFile() != DATE_FILE_OK ) return 0 ;
  unsigned int nfiles = dFileManager.GetNFiles();
  cout << "nfiles = " << nfiles << endl;
  // Open the file and loop over events
  unsigned char *eventBuffer;
  if ( nfiles ) { // There are valid files to unpack
    eventBuffer =  dFileManager.GetNextEvent(); // Get the pointer to the first word of the next event,
                                         // It is NULL if we have reached the end of files.
                                         // The event received here is a DAQ event !
                                         // A DAQ event may be of Type:
                                         // START_OF_RUN, END_OF_RUN,
                                         // START_OF_BURST (corresponds to a Start of Spill in MICE)
                                         // END_OF_BURST (corresponds to a End of Spill in MICE)
                                         // PHYSICS_EVENT (contains all the data for a Spill)
                                         // CALIBRATION_EVENT (may contains data from a single
                                         // LDC taken in between spills)
                                         // only START_OF_BURST, END_OF_BURST and PHYSICS_EVENT events are
                                         // embedded in a super event structure generated by the eventbuilder
   while ( eventBuffer ) { // Loop over valid DAQ events
      try {
	thePM.Process(eventBuffer); // Loop over the data and call the Proccess() function
	                            // of the appropriate MDprocessor object when the corresponding
                                    // structure is met.
      }
      // Deal with exceptions
      catch ( MDexception & lExc) {
	std::cerr << "Unpacking exception,  DAQ Event skipped" << std::endl;
	std::cerr <<  lExc.GetDescription() << endl;
      }
      catch(std::exception & lExc) {
	std::cerr << "Standard exception" << std::endl;
	std::cerr << lExc.what() << std::endl;
      }
      catch(...) {
	std::cerr << "Unknown exception occurred..." << std::endl;
      }
      eventBuffer =  dFileManager.GetNextEvent();
    }
   rootFile->Write();
  } else {
    cerr << "Error in opening the file. Aborted." << endl;
  }
  // Good practice: delete objects created with new;
  delete dbbProc;
  delete sorProc;

  return 0;
} /* End of main */


