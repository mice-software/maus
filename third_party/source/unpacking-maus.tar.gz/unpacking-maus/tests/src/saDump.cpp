
/***************************************************************************
 *             Stand Alone example for  DATE files unpacking               *
 * $Log: saDump.cpp,v $
 * Revision 1.3  2009/04/21 12:41:54  daq
 * Remove runNumber argument
 *
 * Revision 1.2  2008/04/29 07:38:55  daq
 * change type of _eventBuffer form unsigned char* to char*.
 *
 * Revision 1.1  2008/04/14 11:40:45  daq
 * Initial revision
 *
 * Revision 1.2  2008/04/10 11:14:38  daq
 * Introduce arguments for filename and file path
 *
 * Revision 1.1  2008/01/25 14:14:31  daq
 * Initial revision
 *
 *
 * Originally created by J.S. Graulich january 2008                        *
 *                                                                         *
 ***************************************************************************/

#define VID "1.21"

#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "MDevent.h"
#include "event.h"
#include "MDdateFile.h"
#include "MDargumentHandler.h"


using namespace std;

/* Simple main */
int main( int argc, char **argv ) {
 
  MDargumentHandler argh("Stand alone unpacking application. It prints unpacked data on the standard output");

  argh.AddArgument("help","print this message","h");
  argh.AddArgument("directory","path for the data file","d","<string>","/data/mice" );
  argh.AddArgument("file","data file name","f","<string>","mandatory");
  //  argh.AddArgument("run-number","run number","r","<int>","0");

  if ( argh.ProcessArguments(argc,argv) ) { argh.Usage(); return -1; }

  if ( argh.GetValue("help") ) { argh.Usage(); return 0; }

  string stringBuf;
  char filepath[128];
  char filename[128];

  if ( argh.GetValue("directory",stringBuf) != MDARGUMENT_STATUS_OK ) return -1;
  strcpy(filepath,stringBuf.c_str());
  if ( argh.GetValue("file",stringBuf) != MDARGUMENT_STATUS_OK ) return -1;
  strcpy(filename,stringBuf.c_str());

  cout << "Data File = " << filepath << "/" << filename << endl;

  // if ( argh.GetValue("r",stringBuf) != MDARGUMENT_STATUS_OK ) return -1;
  // cout << " run number " << stringBuf << endl;

  MDdateFile dFile(filename,filepath);

  MDevent mdEvent;
  unsigned char *eventBuffer;
  unsigned int eventCount(0);

  if ( dFile.OpenFile() == DATE_FILE_OK ) {
    while ( eventBuffer = dFile.GetNextEvent() ) {
      cout << "Event Count : " << eventCount++ << endl;
      unsigned char* ptr = eventBuffer;
      try {
	mdEvent.SetDataPtr(ptr);
	mdEvent.Dump();
      }
      catch ( MDexception & lExc) {
	// reset severity
	std::cerr << "Unpacking exception, skipping DAQ Event" << std::endl;
      }
      catch(std::exception & lExc) {
	std::cerr << "Standard exception" << std::endl;
	std::cerr << lExc.what() << std::endl;
      }
      catch(...) {
	std::cerr << "Unknown exception occurred..." << std::endl;
      }
    }
  } else {
    cout << "Error in opening the file. Aborted." << endl;
  }
  return 0;  
} /* End of main */
