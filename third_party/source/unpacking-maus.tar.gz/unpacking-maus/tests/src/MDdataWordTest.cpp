#include "MDdataWordTest.h"

MDdataWordTest::MDdataWordTest()
{
  entryNum=0;
	errores=0;
  outTextFile=0;
  inTextFile=0;
}

MDdataWordTest::~MDdataWordTest()
{}

void MDdataWordTest::ErrorMessage(unsigned int e, unsigned long32 m1, unsigned long32 m2)
{
    cout<<"+++++ ERROR in entry "<<GetEntryNum()<<" +++++"<<endl;
    if(e != entryNum) cout<<"EntryNum "<< e <<" != "<<entryNum<<endl;
    if(m1 != m2) cout<<"measurement "<< m1 <<" != "<< m2 <<endl;
}

bool MDdataWordTest::Store(unsigned long32 measurement)
{
  cout<<dec;
  cout << entryNum <<"  measurement : "<< measurement <<endl;
  if(outTextFile)
    (*outTextFile) << entryNum << " " << measurement<<endl;
  entryNum++;
  return true;
}

bool MDdataWordTest::Compare(unsigned long32 measurement)
{
  cout<<dec;
  unsigned int testEntryNum;
  unsigned long32 testMeasurement;
	if( !inTextFile->good() ){
		cerr<<" *** ERROR in MDdataWordTest::Compare ***"<<endl;
		cerr<<" *** Unable to access entry "<<entryNum<<"    ***"<<endl;
		cerr<<" *** the text file is corrupted  or this is the end of the file    ***"<<endl;
		exit(0);
	}

	(*inTextFile) >> testEntryNum >> testMeasurement;

  if(testEntryNum!=entryNum || testMeasurement!=measurement)
	{
		ErrorMessage(testEntryNum, testMeasurement, measurement);
		errores++;
    entryNum++;
    return true;
  }
  else {

    entryNum++;
    return false;
  }
}

void MDdataWordTest::PrintTestResult()
{
  cout<<"+++++++++++++++++++++++++++++++++++++++++"<<endl;
  cout<<"  Test result : "<<endl;
	cout<<"  Number of operations tested  "<<entryNum<<endl;
	cout<<"  Number of errores  "<<errores<<endl;
	if(  entryNum && !errores ) cout<<"  TEST PASSED :)  "<<endl;
  else cout<<"  TEST FAILED :( "<<endl;
	cout<<"+++++++++++++++++++++++++++++++++++++++++"<<endl;

}












