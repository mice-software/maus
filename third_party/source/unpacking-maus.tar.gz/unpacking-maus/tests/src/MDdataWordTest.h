#ifndef __MDDATWORD_TEST_H
#define __MDDATWORD_TEST_H

#include <sstream>
#include <fstream>
#include <iostream>
#include <string>
#include "MDdateFile.h"

using namespace std;

class MDdataWordTest
{

  protected:
    ofstream* 	outTextFile;
    ifstream* 	inTextFile;

		int errores;
    unsigned int entryNum;
		unsigned long32 measurement;

  public:
    MDdataWordTest();
    ~MDdataWordTest();


    void SetInFile(ifstream* f)			{inTextFile = f;};
    void SetOutFile(ofstream* f)		{outTextFile = f;}

		bool Compare(unsigned long32 measurement);
    bool Store(unsigned long32 measurement);

		unsigned int GetEntryNum()	{return entryNum;};
    void ErrorMessage(unsigned int e, unsigned long32 m1, unsigned long32 m2);

		void PrintTestResult();

};

#endif

