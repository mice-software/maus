/* miceDump, based on Event dump DATE utility program
 * ===============================
 *  1.21   9-Jun-06  RD  Added number of subevents for Super events
 */

#define VID "1.21"

#include <sys/types.h>
#include <unistd.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "MDevent.h"
#include "event.h"
#include "monitor.h"
#include "attributesHandler.h"

#define DESCRIPTION "DATE V3 event dump"
#ifdef AIX
static
#endif
char mpDaemonMainIdent[] = "@(#)""" __FILE__ """: """ DESCRIPTION \
                        """ """ VID """ compiled """ __DATE__ """ """ __TIME__;

#ifndef TRUE
# define TRUE ( 0 == 0 )
#endif
#ifndef FALSE
# define FALSE ( 0 == 1 )
#endif

/* Macros for log strings handling */
#define SP(l) l,sizeof(l)
#define AP(l) &l[strlen(l)],sizeof(l)-strlen(l)

using namespace std;

unsigned char *dataBuffer;
char *dataSource;
char filename[128];
int termin;
int briefOutput;
int noOutput;
int checkData;
int useStatic;
int asynchRead;
int interactive;
int must;
int wfile;
int fd;
int maxGetEvents;
int useTable;
int useAttributes;
int numErrors;
int numChecked;
unsigned int lastEventType;
int numHeaders;
int bytesHeaders;
int numSuperEvents;
int numEventData;
int bytesEventData;
int staticDataBuffer[ 100000 ];
int doOutput;
unsigned int startBunchCrossingLoaded;
unsigned int startBunchCrossing;
unsigned int startOrbitLoaded;
unsigned int startOrbit;
int startEventIdLoaded;
eventIdType startEventId;
int startSerialNbLoaded;
int startSerialNb;
int numEvents;
int gotSuperEvents = FALSE;
int dumpEquipmentHeader;
int dumpCommonDataHeader;

char *mustTable[3] = { "all", "all", 0 };

MDevent mdEvent;

#define HEADER( ev ) ((struct eventHeaderStruct *)ev)


void printPrefix( const int n ) {
  if ( n != 0 ) printf( "+" );
  else          printf( "=" );
} /* End of printPrefix */

int countSubevents( struct eventHeaderStruct *header ) {
  void *endPtr = (unsigned char *)header + header->eventSize;
  struct eventHeaderStruct *subEventHeader = 
    (struct eventHeaderStruct *)((unsigned char *)header + header->eventHeadSize);
  int numOfSubevents = 0;

  while ( (void *)subEventHeader < endPtr ) {
    numOfSubevents++;
    subEventHeader = 
      (struct eventHeaderStruct *)((unsigned char *)subEventHeader + subEventHeader->eventSize);
  }

  return numOfSubevents;
} /* End of countSubevents */

/* Decode and store a monitoring policy table */
#define MAX_ENTRIES 15
char *monitorTable[ MAX_ENTRIES ] = { 0 };
int decodeTable( char *declaration ) {
  char *p = declaration;
  int nEntries = 0;
  while ( *p != 0 ) {
    while ( *p == ' ' ) p++;
    if ( *p != 0 ) {
      char *s = p;
      char *r;
      while ( *p != 0 && *p != ' ' ) p++;
      if ( ( r = (char*)malloc( p-s+1 ) ) == NULL ) {
	perror( "malloc failed " );
	return 1;
      }
      strncpy( r, s, p-s );
      r[ p-s ] = 0;
      if ( nEntries == MAX_ENTRIES-1 ) {
	fprintf( stderr, "Table too complex, cannot store...\n" );
	return( 1 );
      }
      monitorTable[ nEntries++ ] = r;
      /* This part not needed any more (change in syntax of attributes')
      for (; *r != 0; r++ )
	if ( *r == '+' ) *r = ' ';
      */
    }
  }
  return 0;
} /* End of decodeTable */

int decodeTableWithAttributes( char *declaration ) {
  useAttributes = TRUE;
  return decodeTable( declaration );
} /* End of decodeTableWithAttributes */


/* Print the tool's usage instructions */
void usage( char *ourName ) {
  fprintf( stderr,
	   "Usage: %s [-b][-c][-s][-a][-i][-f \"filename\"][-n number][-t \"table\"][-T \"table\"][-# [b|t|n|e]number] dataSource\n\
\t-b: brief output (skip long events)\n\
\t-S: silent\n\
\t-c: check event data\n\
\t-s: use static data buffer\n\
\t-a: use asynchronous reads\n\
\t-i: interactive\n\
\t-f: write selected events to raw file\n\
\t-n: maximum number of events to process\n\
\t-t: monitoring table to be used (e.g. -t \"ALL yes SOB no\")\n\
\t-T: as \"-t\" but the table has monitoring attributes included\n\
\t\t(e.g. -T \"All yes 1 Phy y 1|2 SOB NO 1&5\")\n\
\t-e: dump content of equipment header\n\
\t-D: dump content of common data header (implies \"-e\")\n\
\t-#: wait for given event\n\
\t\t(b:bunchCrossing o:orbit e:orbit-bunchCrossing <nothing>:serial number)\n",
	   ourName );
} /* End of usage */


/* Check the current configuration */
void checkConfig() {
  if ( sizeof( long32 ) != 4 )
    fprintf( stderr, "ERROR; sizeof(long32):%d\n", (int)sizeof(long32) );
  if ( sizeof( long64 ) != 8 )
    fprintf( stderr, "ERROR; sizeof(long64):%d\n", (int)sizeof(long64) );
  if ( sizeof( datePointer ) != sizeof( char* ) ||
       sizeof( datePointer ) != sizeof( void* ) )
    fprintf( stderr,
	     "ERROR: \
sizeof(datePointer):%d \
sizeof(char*):%d \
sizeof(void*):%d\n",
	     (int)sizeof( datePointer ),
	     (int)sizeof( char* ),
	     (int)sizeof( void* ) );
} /* End of checkConfig */


/* Initialise our variables */
void initVars() {
  dataSource = NULL;
  briefOutput = FALSE;
  noOutput = FALSE;
  checkData = FALSE;
  useStatic = FALSE;
  asynchRead = FALSE;
  interactive = FALSE;
  useTable = FALSE;
  useAttributes = FALSE;
  must = FALSE;
  wfile = FALSE;
  fd = 0;
  maxGetEvents = 0;
  numErrors = 0;
  numChecked = 0;
  numHeaders = 0;
  bytesHeaders = 0;
  numSuperEvents = 0;
  numEventData = 0;
  bytesEventData = 0;
  doOutput = TRUE;
  dumpEquipmentHeader = FALSE;
  dumpCommonDataHeader = FALSE;
  startBunchCrossingLoaded = FALSE;
  startOrbitLoaded = FALSE;
  startEventIdLoaded = FALSE;
  startSerialNbLoaded = FALSE;
  numEvents = 0;
} /* End of initVars */


/* Handle all command line arguments */
void handleArgs( int argc, char **argv ) {
  int   optNum;
  
  for ( optNum = 1; optNum != argc; ) {
    if ( strcmp( argv[optNum], "-?" ) == 0 ) {
      usage( argv[0] );
      exit( 0 );
    }
    if ( strcmp( argv[optNum], "-b" ) == 0 ) {
      briefOutput = TRUE; optNum++;
    } else if ( strcmp( argv[optNum], "-S" ) == 0 ) {
      noOutput = TRUE; optNum++;
    } else if ( strcmp( argv[optNum], "-c" ) == 0 ) {
      checkData = TRUE; optNum++;
    } else if ( strcmp( argv[optNum], "-s" ) == 0 ) {
      useStatic = TRUE; optNum++;
    } else if ( strcmp( argv[optNum], "-a" ) == 0 ) {
      asynchRead = TRUE; optNum++;
    } else if ( strcmp( argv[optNum], "-i" ) == 0 ) {
      interactive = TRUE; optNum++;
    } else if ( strcmp( argv[optNum], "-M" ) == 0 ) {
      must = TRUE; optNum++;
    } else if ( strcmp( argv[optNum], "-e" ) == 0 ) {
      dumpEquipmentHeader = TRUE; optNum++;
    } else if ( strcmp( argv[optNum], "-D" ) == 0 ) {
      dumpEquipmentHeader = TRUE; dumpCommonDataHeader = TRUE; optNum++;
    } else if ( strcmp( argv[optNum], "-f" ) == 0 ) {
      wfile = TRUE; optNum++;
      snprintf( SP(filename), "%s", argv[optNum]); optNum++;
    } else if ( strcmp( argv[optNum], "-n" ) == 0 ) {
      optNum++;
      sscanf( argv[optNum], "%d", &maxGetEvents );
      optNum++;
      printf("Taking max. %d events\n",maxGetEvents);
    } else if ( strcmp( argv[optNum], "-t" ) == 0 ) {
      if ( !useTable ) {
	useTable = TRUE; optNum++;
	if ( decodeTable( argv[optNum++] ) != 0 ) {
	  usage( argv[0] );
	  exit( 1 );
	}
      } else {
	fprintf( stderr, "%s: only one \"-t\" and/or \"-T\"\n", argv[0] );
	exit( 1 );
      }
    } else if ( strcmp( argv[optNum], "-T" ) == 0 ) {
      if ( !useTable ) {
	useTable = TRUE; optNum++;
	if ( decodeTableWithAttributes( argv[optNum++] ) != 0 ) {
	  usage( argv[0] );
	  exit( 1 );
	}
      } else {
	fprintf( stderr, "%s: only one \"-t\" and/or \"-T\"\n", argv[0] );
	exit( 1 );
      }
    } else if ( strcmp( argv[optNum], "-#" ) == 0 ) {
      char *s;
      void *i;
      
      optNum++;
      switch ( argv[optNum][0] ) {
      case 'o' :
	s = &argv[optNum][1];
	i = &startOrbit;
	startOrbitLoaded = TRUE;
	break;
      case 'e' :
	s = &argv[optNum][1];
	i = &startEventId;
	startEventIdLoaded = TRUE;
	break;
      case 'b' :
	s = &argv[optNum][1];
	i = &startBunchCrossing;
	startBunchCrossingLoaded = TRUE;
	break;
      default :
	s = &argv[optNum][0];
	i = &startSerialNb;
	startSerialNbLoaded = TRUE;
	break;
      }
      if ( !isdigit( (int)*s ) ) {
	usage( argv[0] );
	exit( 1 );
      }
      if ( i == &startEventId ) {
	int orbit;
	int bunchCrossing;
	char *separator;

	if ( (separator = strchr( s, '-' )) == NULL ) {
	  usage( argv[0] );
	  exit( 1 );
	}
	if ( strrchr( s, '-' ) != separator ) {
	  usage( argv[0] );
	  exit( 1 );
	}
	*separator = 0;
	if ( sscanf( s, "%d", &orbit ) != 1 ) {
	  usage( argv[0] );
	  exit( 1 );
	}
	if ( sscanf( separator+1, "%d", &bunchCrossing ) != 1 ) {
	  usage( argv[0] );
	  exit( 1 );
	}
	LOAD_EVENT_ID( startEventId, 0, orbit, bunchCrossing );
      } else {
	if ( sscanf( s, "%d", (int *)i ) != 1 ) {
	  usage( argv[0] );
	  exit( 1 );
	}
      }
      doOutput = FALSE;
      optNum++;
    } else if ( dataSource == NULL && argv[optNum][0] != '-' ) {
      dataSource = argv[optNum++];
    } else {
      usage( argv[0] );
      exit( 1 );
    }
  }

  if ( briefOutput && noOutput ) {
    fprintf( stderr, "%s: -i and -S switches incompatible\n", argv[0] );
    exit( 1 );
  }
  if ( briefOutput && noOutput ) {
    fprintf( stderr, "%s: -b and -S switches incompatible\n", argv[0] );
    exit( 1 );
  }
  if ( checkData && noOutput ) {
    fprintf( stderr, "%s: -c and -S switches incompatible\n", argv[0] );
    exit( 1 );
  }
  if ( must && useTable ) {
    fprintf( stderr, "%s: -t and -M switches incompatible\n", argv[0] );
    exit( 1 );
  }
} /* End of handleArgs */


/* Setup monitoring source, parameters and characteristics */
void monitorSetup( char *ourName ) {
  int status;
  
  if ( ( status = monitorDeclareMp( DESCRIPTION """ V""" VID ) ) != 0 ) {
    fprintf( stderr,
	     "Cannot declare MP, status: %s\n",
	     monitorDecodeError( status ) );
    exit( 1 );
  }

  if ( dataSource == NULL ) {
    usage( ourName );		/* We must have a data source! */
    exit( 1 );
  }

  if ( ( status = monitorSetDataSource( dataSource ) ) != 0 ) {
    fprintf( stderr,
	     "Cannot attach to monitor scheme, status: %s\n",
	     monitorDecodeError( status ) );
    exit( 1 );
  }

  if ( ( status = monitorSetSwap( FALSE, FALSE ) ) != 0 ) {
    fprintf( stderr,
	     "Cannot set swpping mode, status: %d (0x%08x), %s",
	     status, status, monitorDecodeError( status ) );
    exit( 1 );
  }

  if ( asynchRead ) {
    if ( ( status = monitorSetNowait() ) != 0 ) {
      fprintf( stderr,
	       "Cannot set Asynchronous mode, status: %s\n",
	       monitorDecodeError( status ) );
      exit( 1 );
    }
  }

  if ( must ) {
    if ( ( status = monitorDeclareTable( mustTable ) ) != 0 ) {
      fprintf( stderr,
	       "Cannot set must-monitor mode, status: %s\n",
	       monitorDecodeError( status ) );
      exit( 1 );
    }
    printf( "Entering must-monitor mode. \
WARNING: may stop data acquisition!\n" );
  }

  if ( useTable ) {
    if ( useAttributes )
      status = monitorDeclareTableWithAttributes( monitorTable );
    else
      status = monitorDeclareTable( monitorTable );
    if ( status != 0 ) {
      fprintf( stderr,
	       "Error during monitoring table declaration%s, status: %s\n",
	       useAttributes ? " with attributes" : "",
	       monitorDecodeError( status ) );
      exit( 1 );
    }
  }

  if ( useStatic ) dataBuffer = (unsigned char *)staticDataBuffer;
} /* End of monitorSetup */


/* Get the next event (if possible) */
#define DOTS_AT 5000
int getNextEvent() {
  int status;
  int again;
  int tries = 0;
  
  do {
    again = FALSE;
    if ( useStatic )
      status = monitorGetEvent( staticDataBuffer, sizeof(staticDataBuffer) );
    else
      status = monitorGetEventDynamic( (void **)&dataBuffer );
    if ( asynchRead && status == 0 ) {
      if ( ( useStatic && *(long32 *)staticDataBuffer == 0 ) ||
	   ( !useStatic && dataBuffer == NULL ) ) {
	if ( ((++tries) % DOTS_AT ) == 0 ) {
	  printf( "*" );
	  fflush( stdout );
	}
	again = TRUE;
      }
    }
  } while ( again );
  if ( asynchRead && tries >= DOTS_AT ) printf( "\n" );
  return status;
} /* End of getNextEvent */


/* Prompt for user action */
void promptUser() {
  int status;
  int action = '\n';
  do {
    if ( numErrors != 0 )
      printf( "%d ERROR%s: ",
	      numErrors,
	      numErrors != 1 ? "S" : "" );
    printf( "n[ext event], q[uit], f[lush], l[ogout]: " );
    fflush( stdout );
    if ( (action = getchar() ) != '\n' ) {
      int c;
      do { c = getchar(); } while ( c != '\n' && c != EOF);
    } else {
      action = 'n';
    }
    if ( action == ' ' ) action = 'n';
    if ( action == EOF ) action = 'q';
    if ( action == 'q' ) {
      printf( "Quitting\n" );
      termin = TRUE;
    } else if ( action == 'f' ) {
      if ( (status = monitorFlushEvents()) != 0 ) {
	printf( "Error flushing: %d (0x%08x): %s\n",
		status, status,
		monitorDecodeError( status ) );
      }
    } else if ( action == 'l' ) {
      if ( (status = monitorLogout()) != 0 ) {
	printf( "Error logging out: %d (0x%08x): %s\n",
		status, status,
		monitorDecodeError( status ) );
      }
    } else if ( action != 'n' ) {
      printf( "Unrecognized command \'%c\'\n", action );
    }
  } while ( action != 'n' && !termin );
} /* End of promptUser */

/* Write the event we recieved to a raw file */
int writeEvent() {
  int status;

  struct eventHeaderStruct *ev = (struct eventHeaderStruct *)dataBuffer;
  int dataSize = ev->eventSize;
  if ( fd == 0 ) {
    printf("Opening file %s\n",filename);
    fd=open( filename, O_CREAT|O_WRONLY|O_TRUNC, 0x001a4 );
    if(fd<=0) {
      printf("Error opening file %s\n",filename);
      termin=TRUE;
      return(-1);
    }
  }
  status=write( fd, dataBuffer, dataSize );
  if ( !briefOutput )
    printf("Wrote %d/%d bytes to %s\n",status,dataSize,filename);
  if(status==dataSize) {
    return(0);
  } else {
    return(status);
  }
} /* End of writeEvent */

/* Decode the event we have received */
void decodeEvent() {
  char* ptr = (char*)dataBuffer ;
  mdEvent.SetDataPtr( ptr );
  mdEvent.Dump();

} /* End of decodeEvent */


/* Check the various numbers to see if it is time to start the output */
int checkNumbers() {
  struct eventHeaderStruct *ev = (struct eventHeaderStruct *)dataBuffer;

  if ( startSerialNbLoaded )
    if ( numEvents == startSerialNb )
      return TRUE;

  if ( startBunchCrossingLoaded )
    if ( EVENT_ID_GET_BUNCH_CROSSING( ev->eventId ) == startBunchCrossing )
      return TRUE;

  if ( startOrbitLoaded )
    if ( EVENT_ID_GET_ORBIT( ev->eventId ) == startOrbit )
      return TRUE;

  if ( startEventIdLoaded )
    if ( EQ_EVENT_ID( ev->eventId, startEventId ) )
	 return TRUE;
	 
  return FALSE;
} /* End of checkNumbers */


/* The main monitor loop */
void monitoringLoop() {
  int  status;
  int  timeOfLastPrint = -1;
  int  outCtr = 0;
  char outFlg[] = { '|', '/', '-', '\\', 0 };
  
  termin = FALSE;
  do {
    status = getNextEvent();
    numEvents++;
    if ( status == MON_ERR_EOF ) {
      /* End-of-file: terminate the monitoring loop */
      termin = TRUE;
      
    } else if ( status != 0 ) {
      /* Error: print the corresponding message */
      fprintf( stderr,
	       "Error getting next event: %s\n",
	       monitorDecodeError( status ) );
      
    } else {
      /* Event received OK */
      if ( !doOutput ) doOutput = checkNumbers();
      if ( doOutput ) {
	if ( noOutput ) {
	  /* No output: print a "progress" cursor */
	  int now = (int)time( NULL );
	  if ( timeOfLastPrint == -1 ) timeOfLastPrint = now;
	  if ( timeOfLastPrint != -1 ) {
	    if ( now - timeOfLastPrint >= 1 ) {
	      timeOfLastPrint = now;
	      printf( "\r%c", outFlg[ outCtr++ ] );
	      if ( outFlg[ outCtr ] == 0 ) outCtr = 0;
	      fflush( stdout );
	    }
	  }
	} else if ( wfile ) {
	  if ( writeEvent() ) {
	    termin = TRUE;
	    break;
	  }
	} else {
	  /* Normal output: print the content of the event */
	  decodeEvent();
	  if ( interactive ) promptUser();
	}
      }
      
      /* If Dynamic mode, free the data buffer and invalidate the pointer */
      if ( !useStatic ) {
	free( dataBuffer );
	dataBuffer = NULL;
      }
    }
    
    if( maxGetEvents > 0 && numEvents >= maxGetEvents )
      termin = TRUE;

    if ( !interactive )	/* Terminate on error (unless interactive) */
      termin = termin | ( numErrors != 0 );
    
  } while ( status == 0 && !termin );
  if ( noOutput ) printf( "\n" );
  if ( wfile && fd != 0 ) {
    status=close(fd);
  }
} /* End of monitoringLoop */


/* Our main */
int main( int argc, char **argv ) {
  checkConfig();
  initVars();
  handleArgs( argc, argv );
  monitorSetup( argv[0] );
  monitoringLoop();
  if ( checkData && numErrors != 0 )
    fprintf( stderr,
	     "ERROR%s: %d\n", numErrors != 1 ? "s" : "", numErrors );
  exit( 0 );
} /* End of main */
