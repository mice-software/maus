

#include "MDevent.h"
#include "event.h"
#include "MDdateFile.h"
#include "MDargumentHandler.h"
#include "MDdataWordTest.h"
#include "MDprocessManager.h"
#include "MDfileManager.h"

#include <vector>

using namespace std;

bool GetArguments( int argc, char **argv);
MDdataWordTest *DataTest;

bool compare = true;
string path="dummy", name="dummy", testfile="dummy.txt";
unsigned int nEvents=10000;

void doTest( unsigned long32 m)
{
	if(compare)	DataTest->Compare( m );
	else DataTest->Store( m );
}

void doCompare( unsigned long32 m)
{
	DataTest->Compare( m );
}

void doStore( unsigned long32 m)
{
	DataTest->Store( m );
}

void doPrint( unsigned long32 m)
{
	cout << "test : "<< m << endl;;

}


int main( int argc, char **argv )
{
  if( !GetArguments( argc, argv ) ) return 1;
  DataTest = new MDdataWordTest();
  ofstream OutFile;
  ifstream InFile;
  if(!compare){
    OutFile.open( testfile.c_str() );
    if( ! OutFile )
    {
      cout << "Can't open text file " << std::endl;
      return 0;
    }
    DataTest->SetOutFile( &OutFile );
  }
  else{
    InFile.open( testfile.c_str() );
    if( ! InFile )
    {
      cout << "Can't open text file " << std::endl;
      return 0;
    }
    DataTest->SetInFile( &InFile );
  }

  MDprocessManager thePM;
  thePM.SetTest( &doTest );
  //thePM.Disable("V1290");
  thePM.Disable("V1731");
  //thePM.Disable("V1724");
  //thePM.Disable("V830");

  //MDdateFile dFile( name.c_str(), path.c_str() );
  MDfileManager dFileManager;
  //dFileManager.AddFile("02377.000", path.c_str());
  //dFileManager.AddFile("02377.001", path.c_str());
  //dFileManager.AddRun("02375", path.c_str());
  //dFileManager.AddRun("02377", path.c_str());
  unsigned int nfiles = dFileManager.AddRun(name.c_str(), path.c_str());

  unsigned char *eventBuffer;
  if ( nfiles ) { // The file can be opened
    eventBuffer =  dFileManager.GetNextEvent();
		unsigned int eventCount=0;
    while ( eventBuffer && eventCount<nEvents ) { // Loop over valid DAQ events
      try {
	      thePM.Process(eventBuffer);
			}
      // Deal with exceptions
      catch ( MDexception & lExc) {
        cerr << "Unpacking exception,  DAQ Event skipped" << std::endl;
        cerr <<  lExc.GetDescription() << endl;
      }
      catch(std::exception & lExc) {
        cerr << "Standard exception" << std::endl;
        cerr << lExc.what() << std::endl;
      }
      catch(...) {
        cerr << "Unknown exception occurred..." << std::endl;
      }
      eventBuffer =  dFileManager.GetNextEvent();
			eventCount++;
    }
  } else {
    cerr << "Error in opening the file. Aborted." << endl;
  }

  if(compare){
    InFile.close();
		DataTest->PrintTestResult();
	}
  else OutFile.close();

  delete DataTest;

  return 1;
}

bool GetArguments( int argc, char **argv)
{
  string stringBuf, storef, comparef;
  int intBuf;
  MDargumentHandler argh("Stand alone unpacking application. It verifies the consistency of the unpacked data. ");

  argh.AddArgument("help","print this message","h");
  argh.AddArgument("directory","path for the data file","d","<string>","/data/mice" );
  argh.AddArgument("run","run name","r","<string>","mandatory");
  argh.AddArgument("storefile","text file for recording","s","<string>","no");
  argh.AddArgument("comparefile","text file for comparison","c","<string>","no");
  argh.AddArgument("events","number of events","n","<int>","100");

  if ( argh.ProcessArguments(argc,argv) ) { argh.Usage(); return false; }

  if ( argh.GetValue("help") ) { argh.Usage(); return 0; }

  if ( argh.GetValue("directory",stringBuf) != MDARGUMENT_STATUS_OK ) return false;
  path = stringBuf;

  if ( argh.GetValue("run",stringBuf) != MDARGUMENT_STATUS_OK ) return false;
  name = stringBuf;

  if ( argh.GetValue("events",intBuf)  != MDARGUMENT_STATUS_OK ) return false;
  nEvents = intBuf;

  if ( argh.GetValue("storefile",stringBuf) != MDARGUMENT_STATUS_OK ) return false;
  storef = stringBuf;

  if ( argh.GetValue("comparefile",stringBuf) != MDARGUMENT_STATUS_OK ) return false;
  comparef = stringBuf;

  if(storef=="no" && comparef=="no")
    {
      argh.Usage();
      cout<<endl<<"Nothing to do, Use -s or -c options!"<<endl;
      return false;
    }

  if(storef!="no" && comparef!="no")
    {
      argh.Usage();
      cout<<endl<<"Not clear what to do. Use -s or -c options, but not both!"<<endl;
      return false;
    }

  cout<<endl<<" directory : "<<path<<endl;
  cout<<" file : "<<name<<endl;
  cout<<" number of events to test : "<<nEvents<<endl;
  if(storef!="no" && comparef=="no") {
    testfile = storef;
    cout<<" store in : "<<testfile<<endl;
    compare = false;
  }
  if(storef=="no" && comparef!="no")
    {
      testfile = comparef;
      cout<<" compare with : "<<testfile<<endl;
      compare = true;
    }
  cout<<endl;
  return true;
}
