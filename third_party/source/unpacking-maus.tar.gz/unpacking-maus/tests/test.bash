#!/bin/bash

rm  bin/saDump
cd ..
make
cd -
make
#saDump#bin/saDump -d ~/Downloads/ -f 02704.000 >tmp.txt
bin/saDump -d /data -f "2263 02244.000 2267.000 29 hf" 

