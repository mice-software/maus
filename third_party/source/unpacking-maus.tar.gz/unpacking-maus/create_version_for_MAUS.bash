bzr commit
bzr push bzr+ssh://bazaar.launchpad.net/~maus-dev/unpacking/maus/
bzr export unpacking-maus.tar.gz
md5sum unpacking-maus.tar.gz > unpacking-maus.tar.gz.md5

echo "Using the following MAUS_ROOT_DIR:"
echo $MAUS_ROOT_DIR

mv unpacking-maus.tar.gz $MAUS_ROOT_DIR/third_party/source
mv unpacking-maus.tar.gz.md5 $MAUS_ROOT_DIR/third_party/source
