/***************************************************************************
 *                                                                         *
 *                                                                         *
 * Originally created by J.S. Graulich, May 2011                           *
 *                                                                         *
 ***************************************************************************/

#ifndef __MDFRAGMENTV830_H
#define __MDFRAGMENTV830_H

#include "MDdataContainer.h"
#include "MDfragment.h"
#include "MDdataWordV830.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <fstream>

using namespace std;

class MDfragmentV830 : public MDfragment {

 public:
  
  MDfragmentV830( void *d = 0 );
  virtual ~MDfragmentV830(){}
  virtual void SetDataPtr( void *d, uint32_t aSize  );
  virtual void Dump( int atTheTime = 1 );
  virtual void Init();
  //  virtual uint32_t InitPartEventVector();
  uint32_t GetChannel(unsigned int iw);
  uint32_t GetMeasurement(unsigned int iw);

 private:
  unsigned int   _ts;
  unsigned int   _triggerCount;  


};

#endif
