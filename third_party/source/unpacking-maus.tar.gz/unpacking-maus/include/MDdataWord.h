/***************************************************************************
 *                                                                         *
 * $Log: MDdataWord.h,v $
 * Revision 1.1  2008/04/14 11:41:08  daq
 * Initial revision
 *
 * Revision 1.3  2007/07/20 17:23:06  daq
 * Minor change
 *
 * Revision 1.2  2007/06/28 16:29:56  daq
 * First Working version
 *
 * Revision 1.1  2007/06/27 12:01:07  daq
 * Initial revision
 *
 *                                                                         *
 * Originally created by J.S. Graulich june 2007                           *
 *                                                                         *
 ***************************************************************************/

#ifndef __MDDATAWORD_H
#define __MDDATAWORD_H

#include "MDdataContainer.h"

using namespace std;

class MDdataWord : public MDdataContainer {
 public:
  MDdataWord(void *d=0):MDdataContainer(d,4){ if (_data) _valid = true;}

  MDdataWord(MDdataWord& dw) {
    _data  = dw.GetDataPtr();  
    _size  = dw.GetSize();
    _valid = dw.IsValid(); 
  }
  
  MDdataWord(const MDdataWord& dw) {}
  
  virtual ~MDdataWord(){}

  virtual void SetDataPtr( void *d ){
    MDdataContainer::SetDataPtr(d);
    if ( _data ) {
      _size = 4;
      _valid = true;
    }
  }

  virtual void Dump(int atTheTime=1){ 
    if (_valid)
      MDdataContainer::Dump(atTheTime);
    else cout << "  Data Word NOT valid " << endl;
  }
};

#endif
