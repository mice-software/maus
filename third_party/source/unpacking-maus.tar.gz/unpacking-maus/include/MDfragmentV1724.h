/***************************************************************************
 *                                                                         *
 *                                                                         *
 * Originally created by J.S. Graulich, May 2011                           *
 *                                                                         *
 ***************************************************************************/

#ifndef __MDFRAGMENTV1724_H
#define __MDFRAGMENTV1724_H

#include "MDdataContainer.h"
#include "MDfragment.h"
#include "MDdataWordV1724.h"
#include "MDpartEventV1724.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <fstream>

using namespace std;


class MDfragmentV1724 : public MDfragment {

 public:

  MDfragmentV1724( void *d = 0 );
  virtual ~MDfragmentV1724(){}
  virtual void SetDataPtr( void *d, uint32_t aSize );
  virtual void Init();

  virtual void SetTest(DataTestCallback funk) {
    if (_partEventPtr) _partEventPtr->SetTest( funk );
  }

 private:
};

#endif
