/***************************************************************************
 *                                                                         *
 * $Log: MDdataWordV830.h,v $
 * Revision 1.1  2008/04/14 11:41:08  daq
 * Initial revision
 *
 * Revision 1.1  2007/07/20 17:17:09  daq
 * Initial revision
 *
 *
 *                                                                         *
 * Originally created by V. Verguilov  & J.S. Graulich, July 2007          *
 *                                                                         *
 ***************************************************************************/

#ifndef __MDDATWORDV830_H
#define __MDDATWORDV830_H

#include "MDdataWord.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <fstream>


using namespace std;

typedef enum DWV830DataType {
  DWV830_Measurement     = 0x00,
  DWV830_Header          = 0x01,
  DWV830_InvalidData     = 0x1F
} DWV830DataType;

typedef enum DWV830TriggerType {
  DWV830_ExternalTrigger     = 0x00,
  DWV830_TriggerViaTimer     = 0x01,
  DWV830_TriggerViaVME       = 0x02,
  DWV830_InvalidTrigger      = 0x04
} DWV830TriggerType;

class MDdataWordV830 : public MDdataWord {

 public:
  MDdataWordV830( void *d = 0 );
  ~MDdataWordV830(){}

  long32 GetDataType();
  long32 GetGeo();
  long32 GetTriggerType();
  long32 GetWordCount();
  long32 GetTriggerCount();
  long32 GetMeasurement();
  long32 GetChannel();

  virtual void Dump(int atTheTime=1);  
};


ostream &operator<<(ostream &s,MDdataWordV830 &dw);
istream &operator>>(istream &s,MDdataWordV830 &dw);

#endif
