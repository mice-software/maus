/***************************************************************************
 *                                                                         *
 * $Log: MDevent.h,v $
 * Revision 1.1  2008/04/14 11:41:08  daq
 * Initial revision
 *
 * Revision 1.5  2008/01/30 14:57:58  daq
 * Change types of nSubEvents and nFragments to unsigned int
 *
 * Revision 1.4  2008/01/29 16:38:35  daq
 * Introduce private vectors preserving the references of subEvents and fragments
 *
 * Revision 1.3  2007/07/20 17:23:06  daq
 * Introduce default argument for Dump()
 *
 * Revision 1.2  2007/06/28 16:29:56  daq
 * First Working version
 *
 * Revision 1.1  2007/06/27 12:01:07  daq
 * Initial revision
 *
                                                                           *
 * Originally created by J.S. Graulich june 2007                           *
 *                                                                         *
 ***************************************************************************/

#ifndef __MDEVENT_H
#define __MDEVENT_H

#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include <iostream>
#include "event.h"
#include "MDdataContainer.h"
#include "MDeventFragment.h"

using namespace std;

class MDevent : public MDdataContainer  {
  ///////  data   ////////
 private:
  unsigned int            nFragments;
  vector<void *> fragment;

  unsigned int            nSubEvents;
  vector<void *> subEvent;

 public:
  ///////  Member functions   ////////
  MDevent(void *d=0);

  virtual ~MDevent(){}
  virtual void SetDataPtr( void *d );

  void Init();
  eventHeaderStruct* HeaderPtr(){ return (eventHeaderStruct *) _data; }

  unsigned long32  EventSize(){ return  HeaderPtr()->eventSize ; }
  unsigned long32* EventSizePtr(){ return &(HeaderPtr()->eventSize); }

  unsigned long32  Magic(){ return HeaderPtr()->eventMagic ; }
  unsigned long32* MagicPtr(){ return &(HeaderPtr()->eventMagic); }

  unsigned long32  HeadSize(){ return HeaderPtr()->eventHeadSize ; }
  unsigned long32* HeadSizePtr(){ return &(HeaderPtr()->eventHeadSize) ; }

  unsigned long32  Version(){ return HeaderPtr()->eventVersion ; }
  unsigned long32* VersionPtr(){ return &(HeaderPtr()->eventVersion) ; }

  unsigned long32  EventType(){ return HeaderPtr()->eventType ; }
  unsigned long32* EventTypePtr(){ return &(HeaderPtr()->eventType) ; }

  unsigned long32  RunNb(){ return HeaderPtr()->eventRunNb ; }
  unsigned long32* RunNbPtr(){ return &(HeaderPtr()->eventRunNb) ; }
  
  unsigned long32* EventIdPtr(){ return HeaderPtr()->eventId; }

  unsigned long32* TriggerPatternPtr(){ return HeaderPtr()->eventTriggerPattern; }

  unsigned long32* DetectorPatternPtr(){ return HeaderPtr()->eventDetectorPattern; }

  unsigned long32* EventTypeAttributePtr(){ return HeaderPtr()->eventTypeAttribute; }

  unsigned long32  LdcId(){ return HeaderPtr()->eventLdcId; }
  unsigned long32* LdcIdPtr(){ return &(HeaderPtr()->eventLdcId); }

  unsigned long32  GdcId(){ return HeaderPtr()->eventGdcId; }
  unsigned long32* GdcIdPtr(){ return &(HeaderPtr()->eventGdcId); }

  unsigned long32* TimeStampPtr(){ return &(HeaderPtr()->eventTimestamp); }

  unsigned char* PayLoadPtr(){ return (_data + *HeadSizePtr()); }

  virtual void Dump(int atTheTime=1);

  unsigned long32 Nequipment();
  unsigned long32 NsubEvent();

  unsigned long32  PayLoadSize();

  void* GetFragmentPtr(int ifr){ return fragment[ifr]; }
  unsigned long32 GetNFragments(){ return nFragments; }

  void* GetSubEventPtr(int ifr){ return subEvent[ifr]; }
  unsigned long32 GetNSubEvents(){ return nSubEvents; }

  bool IsSuperEvent(){ 
    return TEST_SYSTEM_ATTRIBUTE( HeaderPtr()->eventTypeAttribute, 
				  ATTR_SUPER_EVENT );
  }
};

/////////////////////////////////////////////////////////////////////////////

class MDeventType : public MDdataContainer {
 public:
  MDeventType(void *d=0):MDdataContainer(d){
    if ( _data ) {
      _valid = true;
      _size = sizeof(eventTypeType);
    }
  }
  MDeventType(MDeventType& et) {
    _data  = et.GetDataPtr();
    _size  = et.GetSize();
    _valid = et.IsValid();
  }
  virtual ~MDeventType(){}
};
ostream &operator<<(ostream &s,MDeventType &e);

/////////////////////////////////////////////////////////////////////////////

class MDeventId : public MDdataContainer {
 public:
  MDeventId(void *d=0):MDdataContainer(d){
    if ( _data ) {
      _valid = true;
      _size = EVENT_ID_BYTES;
    }
  }
  virtual ~MDeventId(){}
};
ostream &operator<<(ostream &s,MDeventId &e);

/////////////////////////////////////////////////////////////////////////////

class MDeventTypeAttribute : public MDdataContainer {
 public:
  MDeventTypeAttribute(void *d=0):MDdataContainer(d){
    if ( _data ) {
      _valid = true;
      _size = ALL_ATTRIBUTE_BYTES;
    }
  }
  virtual ~MDeventTypeAttribute(){}
};
ostream &operator<<(ostream &s,MDeventTypeAttribute &e);

/////////////////////////////////////////////////////////////////////////////

class MDtriggerPattern : public MDdataContainer {
 public:
  MDtriggerPattern(void *d=0):MDdataContainer(d){
    if ( _data ) {
      _valid = true;
      _size = EVENT_TRIGGER_PATTERN_BYTES;
    }
  }
  virtual ~MDtriggerPattern(){}
};
ostream &operator<<(ostream &s,MDtriggerPattern &e);

/////////////////////////////////////////////////////////////////////////////

class MDdetectorPattern : public MDdataContainer {
 public:
  MDdetectorPattern(void *d=0):MDdataContainer(d){
    if ( _data ) {
      _valid = true;
      _size = EVENT_DETECTOR_PATTERN_BYTES;
    }
  }
  virtual ~MDdetectorPattern(){}
};
ostream &operator<<(ostream &s,MDdetectorPattern &e);


#endif
