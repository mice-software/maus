/***************************************************************************
 *                                                                         *
 * Originally created by J.S. Graulich May 2011                            *
 *                                                                         *
 ***************************************************************************/

#ifndef __MDPROCESSOR_H
#define __MDPROCESSOR_H

#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <iomanip>
#include <utility>
#include <vector>
#include <string>

#include "MDdataContainer.h"

using namespace std;

class MDprocessManager;

class MDprocessor {
 protected:
  //  void* _objPtr; // the object the process will fill
  //  void* _parPtr; // The parameter structure used for the process
  MDprocessManager* _proMan; // The process manager this process belongs to
  //  bool  _valid;

 public:
  enum ReturnCode {
    OK           = 0,
    FormatError  = 1,
    CastError    = 2,
    GenericError = 3
  };

  // MDprocessor(void *aObjPtr=NULL, void *aParPtr=NULL):_objPtr(aObjPtr),_parPtr(aParPtr),_proMan(0){}
 MDprocessor():_proMan(NULL){}  virtual ~MDprocessor(){}

  virtual int Process(MDdataContainer*) {return OK;}
  void SetProcessManager(MDprocessManager* aPM){_proMan=aPM;}

  MDprocessManager* GetProcessManager(){return _proMan;}

  uint32_t GetRunNumber();
  uint32_t GetTimeStamp();
  string   GetTimeString();
  uint32_t GetLdcId();
  uint32_t GetEventType();
  uint32_t GetSpillNumber();
  uint32_t GetPhysEventNumber();
  uint32_t GetPartEventNumber();
  uint32_t GetEquipmentType();
  uint32_t GetBoardId();

};

#endif
