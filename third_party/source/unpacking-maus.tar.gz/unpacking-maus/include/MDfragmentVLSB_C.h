/***************************************************************************
 *                                                                         *
 *                                                                         *
 * Originally created by J.S. Graulich, May 2011                           *
 *                                                                         *
 ***************************************************************************/

#ifndef __MDFRAGMENTVLSB_C_H
#define __MDFRAGMENTVLSB_C_H

#include "MDdataContainer.h"
#include "MDfragment.h"
#include "MDdataWordVLSB.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <fstream>

using namespace std;

class MDfragmentVLSB_C : public MDfragment {

 public:
  
  MDfragmentVLSB_C( void *d = 0 );
  virtual ~MDfragmentVLSB_C(){}
  virtual void SetDataPtr( void *d, uint32_t aSize  );
  virtual void Dump( int atTheTime = 1 );
  virtual void Init();
  //  virtual uint32_t InitPartEventVector();

  unsigned int GetBankLength(int iBank);
  uint32_t* GetDataWordPtr(int aI);

 private:
  unsigned int   _bankLength[4];

};

#endif
