/***************************************************************************
 *                                                                         *
 * $Log: MDdateFile.h,v $
 * Revision 1.2  2008/04/29 07:40:51  daq
 * Change type of _eventBuffer from unsigned char* to char*.
 *
 * Revision 1.1  2008/04/14 11:41:08  daq
 * Initial revision
 *
 * Revision 1.1  2008/01/25 14:14:50  daq
 * Initial revision
 *
 *
 * Originally created by J.S. Graulich january 2008                        *
 *                                                                         *
 ***************************************************************************/

#ifndef __MDDATEFILE_H
#define __MDDATEFILE_H

#include <stdint.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <iostream>
#include <fstream>

typedef enum dateFileStatus_t {
  DATE_FILE_OK             = 0,
  DATE_FILE_ERROR_IO       = 1,
  DATE_FILE_ERROR_FORMAT   = 2,
  DATE_FILE_ERROR_EOF      = 3,
  DATE_FILE_NOT_OPEN       = 4
} dateFileStatus_t ;


using namespace std;

class MDdateFile {
 protected:
  long                   _curPos;            // current stream position in file
  ifstream               _ifs;               // Input File Stream
  unsigned char*         _eventBuffer;

 public:
  string                 _filePath;
  string                 _fileName;
  uint32_t               _eventSize;
  long                   _fileSize;
  long                   _nBytesRead;
  dateFileStatus_t       _status;

  MDdateFile(string fn, string fp=".");
  ~MDdateFile(){ free(_eventBuffer) ; }

  void SetFileName(string fn) { _fileName = fn ;}
  string GetFileName()        { return _fileName;}

  void SetFilePath(string fp) { _filePath = fp ;}
  string GetFilePath()        { return _filePath;}

  bool IsOk() { return !_status; }

  dateFileStatus_t  OpenFile();
  unsigned char*    GetNextEvent();

 private:

};

#endif
