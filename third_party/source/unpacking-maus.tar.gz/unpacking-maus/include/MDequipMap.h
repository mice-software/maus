/***************************************************************************
 *                                                                         *
 * $Log: MDequipMap.h,v $
 * Revision 1.3  2009/04/21 12:45:44  daq
 * Introduce PCI6254 and V1731
 *
 * Revision 1.2  2008/04/29 07:41:49  daq
 * Declare Dump() and GetType()
 *
 * Revision 1.1  2008/04/14 11:41:08  daq
 * Initial revision
 *
 * Revision 1.1  2008/01/25 10:03:51  daq
 * Initial revision
 *
 *
 * Originally created by J.S. Graulich january 2008                        *
 *                                                                         *
 ***************************************************************************/
#ifndef __MDEQUIPMAP_H
#define __MDEQUIPMAP_H

#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include "MDpartEventV1290.h"
#include "MDpartEventV1724.h"
#include "MDpartEventV830.h"
#include "MDpartEventV1731.h"
#include "MDpartEventPCI6254.h"

#define ADD_EQUIP_IN_MAP(t,s)  _equipMap[(t)] = new MDequipDesc((#s),new MDpartEvent##s)

using namespace std;

class MDequipDesc;

typedef map<unsigned int, MDequipDesc*> equipMap;

class MDequipDesc {
 private:
  string              name;
  MDdataContainer*    dcPtr;

  public:
  MDequipDesc(string s, MDdataContainer* ptr):name(s),dcPtr(ptr){
    //    cout << " Create a new MDequipDesc" << endl;
  }
  ~MDequipDesc(){}
  string GetName(){return name;}
  MDdataContainer* GetDataContainerPtr(){return dcPtr;}
};

class MDequipMap {
 public:
  static equipMap _equipMap;
  static int _count;

  MDequipMap();
  ~MDequipMap(){
    // Intentionnaly left empty.
    // The pointers don't have to be deleted because they are created only once
    // (the map is static)
  }
 
  void Dump();

  equipMap::iterator find( unsigned int type ) { 
    return _equipMap.find(type); 
  }

  string GetName( unsigned int type ) { 
    return _equipMap[type]->GetName();
  }

  unsigned int GetType( string name ); 

  MDdataContainer* GetDataContainerPtr(int type) {
    return _equipMap[type]->GetDataContainerPtr();
  }

};

#endif
