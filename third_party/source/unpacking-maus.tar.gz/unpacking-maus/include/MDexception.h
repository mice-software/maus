/***************************************************************************
 * Originally created by J.S. Graulich June 2010                           *
 *                                                                         *
 ***************************************************************************/
#ifndef __MDEXCEPTION_H
#define __MDEXCEPTION_H

#include <cstdlib>
#include <cstring>
#include <iostream>
#include <sstream>
#include <string>
#include <list>
#include <exception>

class MDexception {

 public:
  enum MD_SEVERITY
    {
      MD_ERROR_WARNING=0,
      MD_ERROR_SERIOUS=1,
      MD_ERROR_FATAL=2
    };

  MDexception(const std::string & aErrorDescription = "",MD_SEVERITY = MD_ERROR_SERIOUS );
  // Default destructor has nothing to do
  // except be declared virtual and non-throwing.
  ~MDexception() throw() {}
  std::string GetDescription() {return mErrorDescription;}

 protected: // sometimes derived classes want to manipulate this one
  std::string mErrorDescription;
  MD_SEVERITY mSeverity;

};

#endif
