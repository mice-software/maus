/***************************************************************************
 *                                                                         *
 * $Log: MDeventFragment.h,v $
 * Revision 1.1  2008/04/14 11:41:08  daq
 * Initial revision
 *
 * Revision 1.6  2008/04/08 14:04:01  daq
 * Introduce vector of particle events.
 * Introduce new member function InitPartEventVector().
 *
 * Revision 1.5  2008/01/25 10:10:47  daq
 * Introduce the new MDequipMap scheme
 *
 * Revision 1.4  2007/12/14 09:43:15  daq
 * *** empty log message ***
 *
 * Revision 1.3  2007/07/20 17:23:06  daq
 * Add V830.
 * Introduce equipment Map
 *
 * Revision 1.3  2007/07/17 10:29:33  daq
 * Added diffrent equipments enum and STL map.
 *
 * Revision 1.2  2007/06/28 16:29:56  daq
 * First Working version
 *
 * Revision 1.1  2007/06/27 12:01:07  daq
 * Initial revision
 *
                                                                           *
 * Originally created by J.S. Graulich june 2007                           *
 *                                                                         *
 ***************************************************************************/

#ifndef __MDEVENTFRAGMENT_H
#define __MDEVENTFRAGMENT_H

#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <map>
#include "event.h"
#include "MDequipMap.h"
#include "MDdataWord.h"
#include "MDpartEventV1290.h"
#include "MDpartEventV1724.h"
#include "MDdataWordV830.h"
#include "MDdataContainer.h"

using namespace std;

class MDeventFragment  : public MDdataContainer {
 private:
  unsigned int            nPartEvents;
  vector<void *> partEvent;
  void Init();

 public:
  MDeventFragment(void *d=0);

  virtual ~MDeventFragment(){}
  virtual void SetDataPtr( void *d );

  equipmentHeaderStruct* HeaderPtr(){ return (equipmentHeaderStruct *) _data; }

  unsigned long32  EquipmentSize(){ return  HeaderPtr()->equipmentSize ; }
  unsigned long32* EquipmentSizePtr(){ return &(HeaderPtr()->equipmentSize) ; }
  unsigned long32  EquipmentType(){ return  HeaderPtr()->equipmentType ; }
  unsigned long32* EquipmentTypePtr(){ return &(HeaderPtr()->equipmentType); }
  unsigned long32  EquipmentId(){ return  HeaderPtr()->equipmentId ; }
  unsigned long32* EquipmentIdPtr(){ return &(HeaderPtr()->equipmentId); }
  unsigned long32* EquipmentTypeAttributePtr(){ return HeaderPtr()->equipmentTypeAttribute; }
  unsigned long32  BasicElementSize(){ return  HeaderPtr()->equipmentBasicElementSize ; }
  unsigned long32* BasicElementSizePtr(){ return &(HeaderPtr()->equipmentBasicElementSize); }

  unsigned long32  EquipmentDataSize(){ 
    return *EquipmentSizePtr() - sizeof(equipmentHeaderStruct);
  }

  unsigned char* EquipmentDataPtr(){ 
    return _data + sizeof(equipmentHeaderStruct); 
  }

  virtual void Dump(int atTheTime=1);
  unsigned long32 InitPartEventVector();

  void* GetPartEventPtr(int ipe){ return partEvent[ipe]; }
  unsigned long32 GetNPartEvents(){ return nPartEvents; }

};

#endif
