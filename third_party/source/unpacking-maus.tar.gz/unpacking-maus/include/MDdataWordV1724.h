/***************************************************************************
 *                                                                         *
 * $Log: MDdataWordV1724.h,v $
 * Revision 1.1  2008/04/14 11:41:08  daq
 * Initial revision
 *
 * Revision 1.3  2008/01/31 00:36:13  daq
 * change type of GetSample()
 *
 * Revision 1.2  2008/01/25 10:02:51  daq
 * Full review.
 *
 * Revision 1.1  2007/12/14 09:43:15  daq
 * Initial revision
 *
 *
 *                                                                         *
 * Originally created by V.Verguilov, November 2007                        *
 *                                                                         *
 ***************************************************************************/

#ifndef __MDDATWORDV1724_H
#define __MDDATWORDV1724_H

#include "MDdataWord.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <fstream>

using namespace std;

typedef enum DWV1724Header {
  DWV1724_Header_Sync                = 0xA0000000,
  DWV1724_Header_Sync_Word           = 0,
  DWV1724_Header_Sync_Mask           = 0xF0000000,
  DWV1724_Header_WordCount_Mask      = 0x0FFFFFFF,
  DWV1724_Header_WordCount_Word      = 0,
  DWV1724_Header_WordCount_Shift      = 0,
  DWV1724_Header_Geo_Mask            = 0xF8000000,
  DWV1724_Header_Geo_Word            = 1,
  DWV1724_Header_Geo_Shift           = 27,
  DWV1724_Header_ZLE_Mask            = 0x01000000,
  DWV1724_Header_ZLE_Word            = 1,
  DWV1724_Header_ZLE_Shift           = 24,
  DWV1724_Header_Pattern_Mask        = 0x00FFFF00,
  DWV1724_Header_Pattern_Word        = 1,
  DWV1724_Header_Pattern_Shift       = 8,
  DWV1724_Header_ChannelMask_Mask    = 0x000000FF,
  DWV1724_Header_ChannelMask_Word    = 1,
  DWV1724_Header_ChannelMask_Shift    = 0,
  DWV1724_Header_EventCounter_Mask   = 0x00FFFFFF,
  DWV1724_Header_EventCounter_Word   = 2,
  DWV1724_Header_EventCounter_Shift  = 0,
  DWV1724_Header_TriggerTimeTag_Mask = 0xFFFFFFFF,
  DWV1724_Header_TriggerTimeTag_Word = 3,
  DWV1724_Header_TriggerTimeTag_Shift = 0 

} DWV1724Header;

typedef enum DWV1724Sample {
  DWV1724_Sample_Shift      = 16,
  DWV1724_Sample_DataMask   =  0x00003FFF,
  DWV1724_Sample_CheckMask  =  0xC000C000

} DWV1724Sample;


class MDdataWordV1724 : public MDdataWord {

 public:
  
  MDdataWordV1724( void *d = 0 );
  ~MDdataWordV1724(){}

  int16_t GetSample(unsigned int is) {
    return (Get32bWordPtr()[0] >> is*DWV1724_Sample_Shift) & DWV1724_Sample_DataMask;
  }

  bool   IsValid(){
    return !( Get32bWordPtr()[0] &  DWV1724_Sample_CheckMask);
  }

  virtual void Dump( int atTheTime = 1 );

 private:
};

ostream &operator<<(ostream &s,MDdataWordV1724 &dw);
istream &operator>>(istream &s,MDdataWordV1724 &dw);


#endif
