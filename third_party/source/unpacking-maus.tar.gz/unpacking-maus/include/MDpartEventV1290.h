/***************************************************************************
 *                                                                         *
 * $Log: MDpartEventV1290.h,v $
 * Revision 1.2  2009/04/21 12:46:53  daq
 * Introduce Trigger Time Tag and Bunch ID
 *
 * Revision 1.1  2008/04/14 11:41:08  daq
 * Initial revision
 *
 * Revision 1.4  2008/04/10 11:09:24  daq
 * Debug GetNHits to allow TDC errors.
 *
 * Revision 1.3  2008/04/08 14:00:08  daq
 * Introduce vector of Hits (leading edge and trailing edge).
 * Implement GetNHitsPerChannel(unsigned int ich,char t).
 * ich = channel number
 * t = measurement type ( 'l' for leading edge [default] or 't' for trailing edge.
 *
 * Revision 1.2  2008/01/30 14:55:32  daq
 * Introduce user friendly functions for unpacking, like GetHitMeasurement(int)
 * See exemple in Dump() method
 *
 * Revision 1.1  2008/01/25 10:14:02  daq
 * Initial revision
 *
 *                                                                         *
 * Originally created by J.S. Graulich, December 2007                      *
 *                                                                         *
 ***************************************************************************/

#ifndef __MDPARTEVENTV1290_H
#define __MDPARTEVENTV1290_H

#include "MDdataContainer.h"
#include "MDdataWordV1290.h"
#include <stdlib.h>
#include <vector>
#include <stdio.h>
#include <iostream>
#include <fstream>

using namespace std;

#define V1290_NCHANNELS    32


class MDpartEventV1290 : public MDdataContainer {

 public:
  
  MDpartEventV1290( void *d = 0 );
  virtual ~MDpartEventV1290(){}
  virtual void SetDataPtr( void *d );

  void Init();
  unsigned int GetEventCount();

  unsigned int GetGeo(){ return _geo; }

  unsigned int GetNHits(unsigned int ich=32,char t='a'); 

  unsigned int GetWordCount();

  unsigned int GetStatus();
  unsigned int GetTriggerTimeTag(){ return _triggerTimeTag; }
  unsigned int GetBunchID(unsigned int unit=4);

  unsigned int GetHitMeasurement(unsigned int ih, unsigned int ich, char t);

  virtual void Dump( int atTheTime = 1 );

 private:

  long32         _tdcStatus;
  unsigned int   _wordCount;
  unsigned int   _geo;
  unsigned int   _triggerTimeTag;
  unsigned int   _bunchID[4];
  unsigned int   _eventID[4];
  unsigned int   _unitWordCount;
  unsigned int   _nLeadingEdgeHits[V1290_NCHANNELS+1];
  unsigned int   _nTrailingEdgeHits[V1290_NCHANNELS+1];
  vector<int>    _leadingEdgeHit[V1290_NCHANNELS];
  vector<int>    _trailingEdgeHit[V1290_NCHANNELS];
};

#endif
