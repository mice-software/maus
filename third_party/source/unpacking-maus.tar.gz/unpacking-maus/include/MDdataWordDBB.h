#ifndef __MDDATWORDDBB_H
#define __MDDATWORDDBB_H

#include "MDdataWord.h"
// #include "MDTypes.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <fstream>

using namespace std;


class MDdataWordDBB : public MDdataWord {

 public:

  MDdataWordDBB(void *d=0);
  ~MDdataWordDBB(){}

 private:

  enum DWDBBMask{
   TriggerCountMask = 0x3FF0000,
   HitCountMask     = 0x1FFF,
   DataTypeMask     = 0xF0000000,
   BoardIdMask      = 0xFC00000,
   SpillNumberMask  = 0xFFFF,
   ChannelIdMask    = 0xFC00000,
   HitTimeMask      = 0x3FFFFF,
   StatusMask       = 0x3F0000,
   SpillWidthMask   = 0x3FFFFF
  };

  enum DWDBBShift{
   TriggerCountShift = 16,
   HitCountShift     = 0,
   DataTypeShift     = 28,
   BoardIdShift      = 22,
   SpillNumberShift  = 0,
   ChannelIdShift    = 22,
   HitTimeShift      = 0,
   StatusShift       = 16,
   SpillWidthShift   = 0
  };

 public:

  enum DWDBBDataType{
   TrailingMeas = 0x2,
   LeadingMeas  = 0x3,
   Header       = 0xD,
   Trailer      = 0xE,
   TriggerCount = 0x8
  };

  unsigned long32 GetDataType();
  unsigned long32 GetTriggerCount();
  unsigned long32 GetHitCount();
  unsigned long32 GetGeo();
  unsigned long32 GetSpillNumber();
  unsigned long32 GetChannelId();
  unsigned long32 GetHitTime();
  unsigned long32 GetStatus();
  unsigned long32 GetSpillWidth();
  bool IsValid();
};


#endif

