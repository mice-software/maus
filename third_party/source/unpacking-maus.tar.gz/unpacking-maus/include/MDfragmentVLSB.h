/***************************************************************************
 *                                                                         *
 *                                                                         *
 * Originally created by J.S. Graulich, May 2011                           *
 *                                                                         *
 ***************************************************************************/

#ifndef __MDFRAGMENTVLSB_H
#define __MDFRAGMENTVLSB_H

#include "MDdataContainer.h"
#include "MDfragment.h"
#include "MDpartEventVLSB.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <fstream>

using namespace std;

class MDfragmentVLSB : public MDfragment {

 public:
  
  MDfragmentVLSB( void *d = 0 );
  virtual ~MDfragmentVLSB(){}
  virtual void SetDataPtr( void *d, uint32_t aSize  );
  virtual void Init();

  unsigned int GetEventNum(unsigned int ih);
  unsigned int GetChannel(unsigned int ih);
  unsigned int GetAdc(unsigned int ih);
  unsigned int GetTdc(unsigned int ih);
  bool GetDiscriBit(unsigned int ih);

  virtual void SetTest(DataTestCallback funk) {
    if (_partEventPtr) _partEventPtr->SetTest( funk );
  }

 private:

};

#endif
