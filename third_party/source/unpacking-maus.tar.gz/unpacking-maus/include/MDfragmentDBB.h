#ifndef __MDFRAGMENTDBB_H
#define __MDFRAGMENTDBB_H

#include "MDdataContainer.h"
#include "MDfragment.h"
#include "MDdataWordDBB.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <fstream>

using namespace std;

#define DBB_NCHANNELS     64
#define DBB_HEADER_WORDS   2
#define DBB_TRAILER_WORDS  2

class MDfragmentDBB : public MDfragment {

 public:

  MDfragmentDBB( void *d = 0 ):MDfragment(d){ Init(); }
  virtual ~MDfragmentDBB(){}

  virtual void SetDataPtr( void *d, uint32_t aSize );
  virtual void Dump( int atTheTime = 1 );
  virtual void Init();

  unsigned int GetSpillWidth()  { return _spillWidth; }
  unsigned int GetSpillNumber() { return _spillNum; }
  unsigned int GetTriggerCount() {return _triggerCount;}
  unsigned int GetHitCount() {return _hitCount;}
  unsigned int GetNLeadingEdgeHits(unsigned int ich) {return _leadingEdgeHit[ich].size();}
  unsigned int GetNTrailingEdgeHits(unsigned int ich) {return _trailingEdgeHit[ich].size();}
  unsigned int GetHitMeasurement(unsigned int ih, unsigned int ich, char t);
  unsigned int GetLeadingTime(unsigned int ih, unsigned int ich){ return GetHitMeasurement(ih, ich, 'l');}
  unsigned int GetTrailingTime(unsigned int ih, unsigned int ich){ return GetHitMeasurement(ih, ich, 't');}

 private:

  unsigned int _spillNum;    /// Number of Spills received by the DBB since last reset
  unsigned int _spillWidth;  /// Number of clock ticks during spill (2.5 ns each)
  unsigned int _triggerCount;/// Number of triggers received
  unsigned int _hitCount;    /// Leading edges only, triggers included

  unsigned int          _nLeadingEdgeHits[DBB_NCHANNELS+1];  /** Number leading edge hits per channel, last channel is total
                                                                 should be equal to _hitCount, channel DBB_NCHANNELS-1 is the
								 trigger it should contain _triggerCount */
  unsigned int          _nTrailingEdgeHits[DBB_NCHANNELS+1]; /** Number trailing edge hits per channel, last channel is total.
								 It is not guaranteed that there is a trailing edge for each leading edge */
  vector<unsigned int>  _leadingEdgeHit[DBB_NCHANNELS];      /// A vector of leading edge hits per channel, last channel is total
  vector<unsigned int>  _trailingEdgeHit[DBB_NCHANNELS];     /// A vector of trailing edge hits per channel, last channel is total
};

ostream &operator<<(ostream &s,MDfragmentDBB &df);

#endif


